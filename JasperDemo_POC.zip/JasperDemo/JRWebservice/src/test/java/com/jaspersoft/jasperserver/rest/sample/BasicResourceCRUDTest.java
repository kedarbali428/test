package com.jaspersoft.jasperserver.rest.sample;

import static com.jaspersoft.jasperserver.rest.sample.Consts.*;

import java.io.File;
import java.io.FileInputStream;

import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpEntityEnclosingRequestBase;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.log4j.PropertyConfigurator;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * 
 * @author Chaim arbiv - carbiv@jaspersoft.com
 *
 */
public class BasicResourceCRUDTest{
	
	static RestAPIUtils restUtils = new RestAPIUtils();
	protected HttpRequestBase httpReq;
	protected HttpResponse httpRes;
	private final Log log = LogFactory.getLog(getClass());
	
	@BeforeClass 
	public static void setUp() throws Exception {
		restUtils.loginToServer();
		PropertyConfigurator.configure(LOG4J_PATH);
		
		// creating a folder in the server
		restUtils.releaseConnection(restUtils.sendAndAssert(new HttpPut(), RESOURCE, RESOURCES_LOCAL_PATH + SAMPLE_FOLDER_RD, HttpStatus.SC_CREATED));		
	}

	@Test
	public void Resource_IMG_PUT_201() throws Exception{
		log.info("creating an image resource on in /SAMPLE_REST_FOLDER folder");
		
		final String parentUri = "/SAMPLE_REST_FOLDER";
		httpRes = resourceCreateUpdate(	new HttpPut(), 
											RESOURCES_LOCAL_PATH+SAMPLE_IMAGE_RD,
											parentUri+"/JUNIT_IMAGE_FILE", 
											RESOURCES_LOCAL_PATH+SAMPLE_IMAGE_BIN, 
											RESOURCE+parentUri); // since the resource is not created yet the put request is sent to the parent resource
		Assert.assertTrue("basic response check did not pass", httpRes.getStatusLine().getStatusCode()==HttpStatus.SC_CREATED);
	}
	
	@Test
	public void Resource_IMG_POST_200() throws Exception
	{
		log.info("updating the image content /SAMPLE_REST_FOLDER folder");
		final String resourceUri = "/SAMPLE_REST_FOLDER/JUNIT_IMAGE_FILE";		
		httpRes = resourceCreateUpdate(	new HttpPost(), 
											RESOURCES_LOCAL_PATH+SAMPLE_IMAGE_RD,
											resourceUri, 
											RESOURCES_LOCAL_PATH+NEW_SAMPLE_IMAGE_BIN, 
											RESOURCE+resourceUri); // since the resource exists we can send the request to the resource
		Assert.assertTrue("basic response check did not pass", httpRes.getStatusLine().getStatusCode()==HttpStatus.SC_OK);
	}
		
	@After
	public void after() throws Exception{
		restUtils.releaseConnection(httpRes);
	}
	
	@AfterClass
	public static void tearDown() throws Exception{
		restUtils.sendAndAssert(new HttpDelete(), RESOURCE+"/SAMPLE_REST_FOLDER", HttpStatus.SC_OK);		
	}
	
	// creates of updates a resource with a binary content like image, jrxl, properties ... 
	private HttpResponse resourceCreateUpdate(HttpRequestBase req, String fileRd, String fileUri, String fileBinPath, String resourceUri) throws Exception
	{
		// resource descriptor
		MultipartEntity reqEntity = new MultipartEntity(HttpMultipartMode.BROWSER_COMPATIBLE);
		String str = IOUtils.toString(new FileInputStream(fileRd));
		reqEntity.addPart(REQUEST_PARAMENTER_RD, new StringBody(str));
		
		//appending the binaries to the request body
		FileBody bin = new FileBody(new File(fileBinPath));
		reqEntity.addPart(fileUri, bin );
		
		//setting the entity in the request
		((HttpEntityEnclosingRequestBase)req).setEntity(reqEntity);
		

		return restUtils.sendRequest(req, resourceUri, null, false);
	}
}
