package com.jaspersoft.jasperserver.rest.sample;

import static com.jaspersoft.jasperserver.rest.sample.Consts.LOG4J_PATH;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.log4j.PropertyConfigurator;
import org.junit.After;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * 
 * @author Thomas Zimmer - mail@ThomasZimmer.net - http://www.thomaszimmer.net
 *
 */
public class RESTV2Test {

	static RestAPIUtils restUtils = new RestAPIUtils();
	protected HttpRequestBase httpReq;
	protected HttpResponse httpRes;
	private final Log log = LogFactory.getLog(getClass());
	
	/**
	 * @param args
	 */
	@SuppressWarnings("static-access")
	public static void main(String[] args) {

		RESTV2Test test = new RESTV2Test();
		try {
			test.setUp();
			test.test();
			test.tearDown();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@BeforeClass 
	public static void setUp() throws Exception {
		restUtils.loginToServer();
		PropertyConfigurator.configure(LOG4J_PATH);
	}
	
	@Test
	public void test() throws Exception {
		
		log.info("generating sample report \"Employees\" from \"/reports/samples/\"");

		// GET request - download report by id from session
		final String resourceUri = "/reports/reports/samples/Employees.pdf";
		
		httpRes = restUtils.sendRequest(new HttpGet(), resourceUri, null, true);
		
		// Write binary content to output file
		InputStream is = httpRes.getEntity().getContent();
		byte[] buffer = new byte[8 * 1024];
		File file = new File("C:/report.pdf");
		OutputStream output = new FileOutputStream(file);
		try {
		    int bytesRead;
		    while ((bytesRead = is.read(buffer)) != -1) {
		      output.write(buffer, 0, bytesRead);
		    }
		  } finally {
		    output.close();
		  }
		is.close();	

		Assert.assertTrue("could not generate report", httpRes.getStatusLine().getStatusCode()==HttpStatus.SC_OK);
	}

	@After
	public void tearDown() throws Exception{
		restUtils.releaseConnection(httpRes);
	}
}
