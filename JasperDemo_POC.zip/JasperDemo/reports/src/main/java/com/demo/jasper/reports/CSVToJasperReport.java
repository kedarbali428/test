package com.demo.jasper.reports;

import java.util.HashMap;
import java.util.Map;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRCsvDataSource;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;

public class CSVToJasperReport {
	
	public void readCsvToJasperReport() throws JRException {
		
		String xmlFile = "src\\main\\resources\\csvtojasper.jrxml";
		
		JasperReport report = JasperCompileManager.compileReport(xmlFile);

		String[] columnNames = new String[] {"Item Name", "Quantity"};

		String csvfileName = "src\\main\\resources\\demo.csv";
		
		JRCsvDataSource ds = new JRCsvDataSource(csvfileName);
		
		ds.setColumnNames(columnNames);
		ds.setFieldDelimiter(',');

		Map<String, Object> parameters = new HashMap<String, Object>();

		JasperPrint jprint = JasperFillManager.fillReport(report, parameters, ds);

		JasperExportManager.exportReportToPdfFile(jprint,"src\\main\\resources\\report2.pdf");
	}
	
	public String getText(){
		
		return "Java method called";
		
	}

}
