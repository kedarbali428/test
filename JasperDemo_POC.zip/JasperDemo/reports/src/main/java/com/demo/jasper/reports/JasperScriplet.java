package com.demo.jasper.reports;

import net.sf.jasperreports.engine.JRDefaultScriptlet;

public class JasperScriplet {
	
	public String getText() {
		return "This is java method";
	}

}
