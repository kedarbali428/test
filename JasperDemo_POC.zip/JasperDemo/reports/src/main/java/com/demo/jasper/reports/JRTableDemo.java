package com.demo.jasper.reports;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;

public class JRTableDemo {
	
	public void start() throws ClassNotFoundException, SQLException, JRException {
		
		String xmlFile = "src\\main\\resources\\table_demo.jrxml";        
		
		JasperReport jreport = JasperCompileManager.compileReport(xmlFile);
		
		Connection ds = MysqlConnectionUtils.getMySQLConnection();
		 
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("query", "SELECT emp_id, emp_name, emp_years_of_exp, emp_designation, emp_salary from emp_demo");
		
		JasperPrint jprint = JasperFillManager.fillReport(jreport,
				params, ds);

		JasperExportManager.exportReportToPdfFile(jprint,
				"src\\main\\resources\\table_demo_report.pdf");
		
	}

}
