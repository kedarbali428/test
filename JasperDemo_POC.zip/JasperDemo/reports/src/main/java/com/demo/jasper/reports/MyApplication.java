package com.demo.jasper.reports;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import net.sf.jasperreports.engine.JRException;

@SpringBootApplication
public class MyApplication {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		//SpringApplication.run(MyApplication.class, args);
				
		try {
			//JRBeanDatasourceDemo beanDatasourceDemo = new JRBeanDatasourceDemo();
			//beanDatasourceDemo.start();
			
			//CSVToJasperReport beanDatasourceDemo = new CSVToJasperReport();
			//beanDatasourceDemo.readCsvToJasperReport();
			
			//JRTableDemo tableDemo = new JRTableDemo();
			//tableDemo.start();
			
			//GenSubreport genSubreport = new GenSubreport();
			//genSubreport.generate();
			
			/*SimpleDateFormat format = new SimpleDateFormat("MM-dd-yyyy hh:mm a");
			String x = format.format(new Date());
			String y = x.substring(11);
			
			//String y = new java.text.SimpleDateFormat("MM-dd-yyyy").format(new java.text.SimpleDateFormat("yyyy-MM-dd").parse("2018-05-01"));
			
			System.out.println("Date : "+x+ "  Time: "+y);*/
			Date d = new Date();
			System.out.println("date: "+d);
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}
}
