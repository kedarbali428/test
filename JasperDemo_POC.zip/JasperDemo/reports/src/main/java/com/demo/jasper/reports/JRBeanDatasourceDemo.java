package com.demo.jasper.reports;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;

import com.demo.jasper.reports.MysqlConnectionUtils;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;
import net.sf.jasperreports.engine.JRParameter;
import net.sf.jasperreports.engine.JRSortField;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.design.JRDesignBand;
import net.sf.jasperreports.engine.design.JRDesignSortField;
import net.sf.jasperreports.engine.design.JRDesignStaticText;
import net.sf.jasperreports.engine.type.SortFieldTypeEnum;
import net.sf.jasperreports.engine.type.SortOrderEnum;

public class JRBeanDatasourceDemo {

	public void start() throws JRException, ClassNotFoundException, SQLException {
		
		String xmlFile = "src\\main\\resources\\emp_report.jrxml";        
		
		JasperReport jreport = JasperCompileManager.compileReport(xmlFile);

		/*Below list ids for car report to try out JRBeanCollectionDataSource
		 * ArrayList<Car> cars = new ArrayList<Car>();

		cars.add(new Car(1L, "Audi", 52642));
		cars.add(new Car(2L, "Mercedes", 57127));
		cars.add(new Car(3L, "Skoda", 9000));
		cars.add(new Car(4L, "Volvo", 29000));
		cars.add(new Car(5L, "Bentley", 350000));
		cars.add(new Car(6L, "Citroen", 21000));
		cars.add(new Car(7L, "Hummer", 41400));
		cars.add(new Car(8L, "Volkswagen", 21600));

		JRBeanCollectionDataSource ds = new JRBeanCollectionDataSource(cars);
*/		
		Connection ds = MysqlConnectionUtils.getMySQLConnection();
		 
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("query", "SELECT emp_id, emp_name, emp_years_of_exp, emp_designation, emp_salary from emp_demo");
		
		ResourceBundle resourceBundle = null;
		
		try(InputStream fis = this.getClass().getResourceAsStream("/bundle/report_messages_en_IN.properties")) {
			   resourceBundle = new PropertyResourceBundle(fis);
			   
		} catch (IOException e) {
			e.printStackTrace();
		}
		params.put(JRParameter.REPORT_LOCALE,Locale.getDefault());
		params.put("REPORT_RESOURCE_BUNDLE",resourceBundle);
		
		
		//params.put("pricerange", 50000);
		/*List<JRSortField> sortList = new ArrayList<>();
		JRDesignSortField sortField = new JRDesignSortField();
		sortField.setName("price");
		sortField.setOrder(SortOrderEnum.ASCENDING);
		sortField.setType(SortFieldTypeEnum.FIELD);
		sortList.add(sortField);
		
		params.put(JRParameter.SORT_FIELDS, sortList);
		*/
			
		
		JasperPrint jprint = JasperFillManager.fillReport(jreport,
				params, ds);
		

		JasperExportManager.exportReportToPdfFile(jprint,
				"src\\main\\resources\\bean_datasource_demo_report.pdf");
		
		
		
		
	}

}
