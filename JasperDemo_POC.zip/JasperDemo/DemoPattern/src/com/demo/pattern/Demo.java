package com.demo.pattern;

public class Demo {

	public static void main(String[] args) {
		
		int k=0;
		for(int i = 1; i <= 3; i++) {
			
			for (int j = 1; j <= i; j++) {
				
				k++;
				System.out.print(k);
				
			}
			
			System.out.println();
		}
		
		for(int i = 3; i >= 1; i--) {
			
			StringBuffer x = new StringBuffer("");
						
			for(int j = 1; j <= i; j++) {
				
				x = x.append(Integer.toString(k));
				k--;
					
			}
			
			System.out.print(x.reverse());
			System.out.println();
		}
	}

}

/*
 * 
   1
   2*3
   4*5*6
   4*5*6
   2*3
   1
   
 */
