package com.demo.jsaperreport;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;

public class PdfFromXmlFile {
	
	public static void main(String[] args) throws JRException {
		
		
	    String filepath  =  "D:\\StyledTextReport\\";
		String filename = "StyledTextReport.jrxml";
		// Compile jrxml file.
		JasperReport report = JasperCompileManager.compileReport( filepath + filename );
		
		//Datasource params, used to pass dynamic parameters or params for conditional queries, or sorting order 
		Map<String, Object> datasourceParam = new HashMap<>();
		
		//Datasource
		JRDataSource dataSource = new JREmptyDataSource();
		
		JasperPrint jasperPrint = JasperFillManager.fillReport(report, datasourceParam, dataSource);
		//Make sure the output directory exists.
	    File outDir = new File("D:\\JasperReportOutput");
	    outDir.mkdirs();
	    
	    filepath = "D:\\JasperReportOutput\\";
	    filename = "RepOutput.pdf";
	    
	    JasperExportManager.exportReportToPdfFile(jasperPrint,
	               filepath + filename);
	        
	    System.out.println("Done!");
	 			
	}

}
