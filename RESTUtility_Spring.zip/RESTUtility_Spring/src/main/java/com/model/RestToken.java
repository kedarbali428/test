package com.model;

public class RestToken {
	private String BhRestToken;
	private String restUrl;
	public String getBhRestToken() {
		return BhRestToken;
	}
	public void setBhRestToken(String bhRestToken) {
		BhRestToken = bhRestToken;
	}
	public String getRestUrl() {
		return restUrl;
	}
	public void setRestUrl(String restUrl) {
		this.restUrl = restUrl;
	}
	@Override
	public String toString() {
		return "RestToken [BhRestToken=" + BhRestToken + ", restUrl=" + restUrl + "]";
	}
}
