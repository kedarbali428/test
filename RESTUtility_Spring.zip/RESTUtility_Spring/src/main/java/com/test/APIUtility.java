package com.test;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.LinkedHashMap;
import java.util.logging.Logger;

import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.model.ClientCredentials;
import com.model.RestToken;

public class APIUtility {

	static Logger logger = Logger.getLogger(APIUtility.class.getName());

	public static void main(String[] args) {

		ClientCredentials credentials = new ClientCredentials();
		credentials.setClientId("d278b3cb-dd73-4fba-a2b0-209af80a357c");
		credentials.setClientSecret("UlN9eHx3d05YOtMNQ3QVFw1q");
		credentials.setUsername("accruepartners.api");
		credentials.setPassword("Accrue2137!");

		try {
			System.out.println(getRestTokenAndRestUrl(credentials));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static RestToken getRestTokenAndRestUrl(ClientCredentials credentials) throws UnsupportedEncodingException {
		logger.info("Getting RestToken and RestUrl");
		//String auth_code = "30:169ead1f-6833-4c93-8fdc-2908946c4e62";//getAuthorizationCode(credentials);
		String auth_code = getAuthorizationCode(credentials);
		LinkedHashMap<String, String> map = getAccessTokenByAuthCode(credentials, auth_code);

		StringBuilder qpmDetails=new StringBuilder();
		qpmDetails.append("?version=*");
		qpmDetails.append("&access_token="+map.get("access_token"));	

		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<Object> response = restTemplate.exchange(
				"https://rest.bullhornstaffing.com/rest-services/login" + qpmDetails.toString(),
				HttpMethod.GET, null, Object.class);

		logger.info("Status code : "+response.getStatusCodeValue());
		LinkedHashMap<String, String> valueMap = (LinkedHashMap<String, String>) response.getBody();
		RestToken restToken = new RestToken();
		restToken.setBhRestToken(valueMap.get("BhRestToken"));
		restToken.setRestUrl(valueMap.get("restUrl"));
		return restToken;
	}

	public static String getAuthorizationCode(ClientCredentials credentials) throws UnsupportedEncodingException {
		logger.info("Getting Authorization code");
		StringBuilder qpmDetails=new StringBuilder();
		qpmDetails.append("?response_type=code");
		qpmDetails.append("&action=Login");
		qpmDetails.append("&client_id="+credentials.getClientId());
		qpmDetails.append("&username="+credentials.getUsername());
		qpmDetails.append("&password="+credentials.getPassword());

		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<Object> response = restTemplate.exchange(
				"https://auth.bullhornstaffing.com/oauth/authorize" + qpmDetails.toString(),
				HttpMethod.POST, null, Object.class);

		logger.info("Status code : "+response.getHeaders().getFirst("Location"));
		String location = response.getHeaders().getFirst("Location");
		System.out.println(location.indexOf("?code=")+"--------"+location.indexOf("&client_id"));
		System.out.println(location.substring(29, 70));
		String authCode = location.substring(location.indexOf("?code=")+6, location.indexOf("&client_id"));
		//LinkedHashMap<String, String> map =  (LinkedHashMap<String, String>) response.getBody();
		System.out.println(URLDecoder.decode(authCode, "UTF-8"));
		return URLDecoder.decode(authCode, "UTF-8");
	}

	public static LinkedHashMap<String, String> getAccessTokenByAuthCode(ClientCredentials credentials, String auth_code) {
		logger.info("Getting Access token by authorization code");
		StringBuilder qpmDetails=new StringBuilder();
		qpmDetails.append("?grant_type=authorization_code");
		qpmDetails.append("&code="+auth_code);
		qpmDetails.append("&client_id="+credentials.getClientId());
		qpmDetails.append("&client_secret="+credentials.getClientSecret());

		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<Object> response = restTemplate.exchange(
				"https://auth.bullhornstaffing.com/oauth/token" + qpmDetails.toString(),
				HttpMethod.POST, null, Object.class);

		logger.info("Status code : "+response.getStatusCodeValue());
		LinkedHashMap<String, String> map =  (LinkedHashMap<String, String>) response.getBody();

		return map;
	}

	public static LinkedHashMap<String, String> getAccessTokenByRefreshToken(ClientCredentials credentials, String refresh_token) {
		logger.info("Getting Access token by refresh code");
		StringBuilder qpmDetails=new StringBuilder();
		qpmDetails.append("?grant_type=refresh_token");
		qpmDetails.append("&refresh_token="+refresh_token);
		qpmDetails.append("&client_id="+credentials.getClientId());
		qpmDetails.append("&client_secret="+credentials.getClientSecret());

		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<Object> response = restTemplate.exchange(
				"https://auth.bullhornstaffing.com/oauth/token" + qpmDetails.toString(),
				HttpMethod.POST, null, Object.class);

		logger.info("Status code : "+response.getStatusCodeValue());
		LinkedHashMap<String, String> map =  (LinkedHashMap<String, String>) response.getBody();

		return map;
	}

}









