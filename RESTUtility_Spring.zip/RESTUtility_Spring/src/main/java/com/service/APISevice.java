package com.service;

import java.io.UnsupportedEncodingException;

import com.model.ClientCredentials;
import com.model.RestToken;
import com.test.APIUtility;

public class APISevice {

	
	public void getCandidate(String candidateId) throws UnsupportedEncodingException {
		ClientCredentials credentials = new ClientCredentials();
		credentials.setClientId("d278b3cb-dd73-4fba-a2b0-209af80a357c");
		credentials.setClientSecret("UlN9eHx3d05YOtMNQ3QVFw1q");
		credentials.setUsername("accruepartners.api");
		credentials.setPassword("Accrue2137!");
		RestToken restToken = APIUtility.getRestTokenAndRestUrl(credentials);
		
		
	}
	
}
