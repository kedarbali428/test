package main.java.com.revelian.position.util;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.JsonToken;

public class SFJsonParsingUtil 
{
	HashMap<String, String> candidateInfo = new HashMap<String, String>();
	static Logger logger = Logger.getLogger(SFJsonParsingUtil.class);
	
	public Map<String,String> getJobRequistionTitle(JsonParser jsonParser,Map<String,String> map)throws JsonParseException, IOException 
	{
		while (jsonParser.nextToken() != JsonToken.END_OBJECT) 
		{
			String name = jsonParser.getCurrentName();
			if ("d".equals(name)) 
			{
				jsonParser.nextToken();
				getJobRequistionTitle(jsonParser,map);
			}
			else if ("jobTitle".equals(name)) 
			{
				jsonParser.nextToken();
				String jobTitle = jsonParser.getText();
				map.put(SFMapConstants.REQUISITION_JOB_TITLE, jobTitle);
				//return jobTitle;
			} 
			else {
				jsonParser.nextToken();
			}
		}
		return map;
	}

	/**
	 * This Method parse jobRequisition for revelianpositionId
	 * @param jsonParser
	 * @param map
	 * @return
	 * @throws JsonParseException
	 * @throws IOException
	 */
	public static Map<String, String> parseJobRequistionDetails(JsonParser jsonParser,Map<String,String> map) throws JsonParseException, IOException
	{
		//String internalStatus = null ;
		while (jsonParser.nextToken() != JsonToken.END_OBJECT)
		{
			String name = jsonParser.getCurrentName();
			if ("d".equals(name)) 
			{
				jsonParser.nextToken();
				parseJobRequistionDetails(jsonParser,map);
			} 
			else if("location".equals(name))
			{
				jsonParser.nextToken();
				String location = jsonParser.getText();
				map.put(SFMapConstants.LOCATION, location);
				logger.info("In parseJobRequistionDetails location " + location);
			}
			else if("country".equals(name))
			{
				jsonParser.nextToken();
				String country = jsonParser.getText();
				map.put(SFMapConstants.COUNTRY, country);
				logger.info("In parseJobRequistionDetails country " + country);
			}
			else if ("revelian_position_id".equals(name)) 
			{
				jsonParser.nextToken();
				String revelianpositionId = jsonParser.getText();
				map.put(SFMapConstants.REVELIAN_POSITION_ID, revelianpositionId);
				logger.info("In parseJobRequistionDetails revelian positionId " + revelianpositionId);
			} else
			{
				jsonParser.nextToken();
			}
		}
		return map;
	}
	
	public static Map<String, String> parseJobRequistionStateDetails(JsonParser jsonParser,Map<String,String> map) throws JsonParseException, IOException
	{
     
		while (jsonParser.nextToken() != JsonToken.END_OBJECT) {
			String name = jsonParser.getCurrentName();
			if ("d".equals(name)) 
			{
				jsonParser.nextToken();
				parseJobRequistionStateDetails(jsonParser,map);
			} else if ("id".equals(name)) {
				jsonParser.nextToken();
				String stateId = jsonParser.getText();
				map.put(SFMapConstants.STATE, stateId);
				logger.info("encontered stateId " + stateId);
				//return jobTitle;
			} else {
				jsonParser.nextToken();
			}
		}
		return map;
	}
	
	public Map<String, String> parseJobRequistionRecruiter(JsonParser jsonParser, Map<String, String> map)throws JsonParseException, IOException 
	{

		while (jsonParser.nextToken() != JsonToken.END_OBJECT) 
		{
			String name = jsonParser.getCurrentName();
			if ("d".equals(name)) 
			{
				jsonParser.nextToken();
				parseJobRequistionRecruiter(jsonParser, map);

			} 
			else if ("operatorRole".equals(name)) 
			{
				jsonParser.nextToken();
				String operatorRole = jsonParser.getText();
				map.put(SFMapConstants.CONTACT_POSITION, operatorRole);
			}
			else if ("firstName".equals(name)) 
			{
				jsonParser.nextToken();
				String firstName = jsonParser.getText();
				map.put(SFMapConstants.CONTACT_FIRSTNAME, firstName);

			}
			else if ("lastName".equals(name)) 
			{
				jsonParser.nextToken();
				String lastName = jsonParser.getText();
				map.put(SFMapConstants.CONTACT_LASTNAME, lastName);
			}
			else if ("email".equals(name)) 
			{
				jsonParser.nextToken();
				String email = jsonParser.getText();
				map.put(SFMapConstants.CONTACT_EMAIL, email);

			}
			else if ("phone".equals(name)) 
			{
				jsonParser.nextToken();
				String phone = jsonParser.getText();
				map.put(SFMapConstants.CONTACT_PHONE, phone);
				map.put(SFMapConstants.CONTACT_MOBILE, phone);
			}
			else 
			{
				jsonParser.nextToken();
			}
		}
		String name = map.get(SFMapConstants.CONTACT_FIRSTNAME) + " " + map.get(SFMapConstants.CONTACT_LASTNAME);
		map.put(SFMapConstants.CONTACT_NAME, name);
		return map;
	}
	
	// Parse jobRequisition for Revelian positionId on JobRequisition

	public static Map<String, String> parseRequistionForPosition(JsonParser jsonParser,	Map<String, String> map) throws JsonParseException, IOException 
	{
		while (jsonParser.nextToken() != JsonToken.END_OBJECT)
		{
			String name = jsonParser.getCurrentName();
			if ("d".equals(name)) 
			{
				jsonParser.nextToken();
				parseRequistionForPosition(jsonParser, map);
			}
			else if ("revelian_position_id".equals(name)) 
			{
				jsonParser.nextToken();
				String revlianPositionId = jsonParser.getText();
				map.put(SFMapConstants.REVELIAN_POSITION_ID, revlianPositionId);
				break;
			}
			else 
			{
				jsonParser.nextToken();
			}
		}

		return map;
	}
}
