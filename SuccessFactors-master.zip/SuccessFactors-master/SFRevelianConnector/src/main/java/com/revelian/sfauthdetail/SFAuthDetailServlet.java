package main.java.com.revelian.sfauthdetail;

import java.io.File;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


public class SFAuthDetailServlet extends HttpServlet {

	/**
	 * This class is used to add SF customer in config.xml file
	 * 
	 */
	static Logger logger = Logger.getLogger(SFAuthDetailServlet.class);
	private static final long serialVersionUID = 1L;
	boolean isSaved=false;
	public static String companyId="";
	public String companyName=null;
	public String companyLink = null;
	public static String userName = null;
	public static String password = null;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html;charset=UTF-8");
		companyId = request.getParameter("CompanyId");
		companyName = request.getParameter("CompanyName");
		companyLink = request.getParameter("CompanyLink");
		userName = request.getParameter("UserName");
	    password = request.getParameter("Password");
		try 
		{
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.newDocument();
			Element rootElement = doc.createElement("Customer");
			Element user = doc.createElement("User");
			
			String rootPath =System.getProperty("catalina.home");
			File file = new File(rootPath+"/conf","SFConnector_config.xml");
//			logger.info("File path:"+file.getAbsolutePath());
			
			boolean flag = false;
			if (!file.exists()) {
				file.createNewFile();
//				logger.info("File path:"+file.getAbsolutePath());
				doc.appendChild(rootElement);
			} else {

				doc = dBuilder.parse(file);
				doc.getDocumentElement().normalize();

				// Return the NodeList on a given tag name
				NodeList nList = doc.getElementsByTagName("User");
				int len = nList.getLength();

				// Update existing record
				for (int i = 0; i < len; i++) {
					Node nNode = nList.item(i);
					Element eElement = (Element) nNode;
					String stringCompanyId = (eElement.getElementsByTagName("Company_Id").item(0)).getTextContent();
					if (companyId.equalsIgnoreCase(stringCompanyId)) {
						flag = true;
						Element eElement1 = (Element) nList.item(i);
						(eElement1.getElementsByTagName("CompanyName").item(0)).setTextContent(companyName);
						(eElement1.getElementsByTagName("CompanyLink").item(0)).setTextContent(companyLink);
						(eElement1.getElementsByTagName("User_Name").item(0)).setTextContent(userName);
						(eElement1.getElementsByTagName("Password").item(0)).setTextContent(password);
						isSaved=true;
						break;
					}
				}
			}

			if (!flag) {
				user = doc.createElement("User");
				doc.getDocumentElement().appendChild(user);

				// CompanyName element
				Element eCompanyId = doc.createElement("Company_Id");
				eCompanyId.appendChild(doc.createTextNode(companyId));
				user.appendChild(eCompanyId);
				
				// CompanyName element
				Element eCompanyName = doc.createElement("CompanyName");
				eCompanyName.appendChild(doc.createTextNode(companyName));
				user.appendChild(eCompanyName);

				// CompanyLink element
				Element eCompanyLink = doc.createElement("CompanyLink");
				eCompanyLink.appendChild(doc.createTextNode(companyLink));
				user.appendChild(eCompanyLink);

				// UserName element
				Element User_Name = doc.createElement("User_Name");
				User_Name.appendChild(doc.createTextNode(userName));
				user.appendChild(User_Name);

				// Password element
				Element Password = doc.createElement("Password");
				Password.appendChild(doc.createTextNode(password));
				user.appendChild(Password);
				
				isSaved=true;
			}

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(file);
			transformer.transform(source, result);
			StreamResult consoleResult = new StreamResult(System.out);
			transformer.transform(source, consoleResult);
			
			String message="";
			 if(isSaved)
			 {
				 message="Data saved successfully";
				 request.getSession().setAttribute("message", message);
				 request.getSession().setAttribute("isSaved", isSaved);
				 response.sendRedirect("SFClientDetail.jsp");
			 }
			 else
			 {
				 message="Unable to save your data";
				 request.getSession().setAttribute("message", message);
				 response.sendRedirect("SFClientDetail.jsp");
			 }
			 
		} catch (Exception ex) {
			logger.error(ex.getMessage());
		}
	}
	
	
	public void  doGet(HttpServletRequest request,HttpServletResponse response) throws IOException , ServletException 
	{
        doPost(request,response);
	}
	
	public String getUserName()
	{
		return userName;
	}
	public String getCompanyId()
	{ 
		return companyId;
	}
	
	public String getPassword()
	{
		return password;
	}
	
	public String getCompanyLink()
	{
		return companyLink;
	}
	
}
