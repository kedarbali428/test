package main.java.com.revelian.candidate.util;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.JsonToken;
import org.codehaus.jackson.map.ObjectMapper;
import main.java.com.revelian.candidate.model.Candidate;

public class SFCandidateJsonParsingUtil {
	HashMap<String, String> candidateInfo = new HashMap<String, String>();
	static Logger logger = Logger.getLogger(SFCandidateJsonParsingUtil.class);

	public  static Map<String, Object> parseCandidateJsonResponse(JsonParser jsonParser, Map<String, Object> map, Candidate candidate) throws JsonParseException, IOException 
	{

		while (jsonParser.nextToken() != JsonToken.END_OBJECT)
		{
			String name = jsonParser.getCurrentName();

			if ("d".equals(name)) {
				jsonParser.nextToken();
				parseCandidateJsonResponse(jsonParser, map, candidate);


			} else if ("candidateId".equals(name)) {

				jsonParser.nextToken();
				String candidateId = jsonParser.getText();

				
				map.put(SFCandidateConstants.SF_CANDIDATE_ID,candidateId);


			} else if ("gender".equals(name)) {

				jsonParser.nextToken();
				String gender = jsonParser.getText().toUpperCase();
				if (gender.equals("NO SELECTION") || gender.isEmpty() || gender == null) {
					gender = "NOT_DISCLOSED";
				}
				candidate.setGender(gender);


			} else if ("cellPhone".equals(name)) {

				jsonParser.nextToken();
				String candidateCellphn = jsonParser.getText();
				candidate.setMobile(candidateCellphn);


			} else if ("homePhone".equals(name)) {

				jsonParser.nextToken();
				String candidateHomePhn = jsonParser.getText();
				candidate.setPhone(candidateHomePhn);


			} else if ("firstName".equals(name)) {

				jsonParser.nextToken();
				String firstName = jsonParser.getText();
				candidate.setFirstName(firstName);


			} else if ("lastName".equals(name)) {

				jsonParser.nextToken();
				String lastName = jsonParser.getText();
				candidate.setLastName(lastName);


			} else if ("contactEmail".equals(name)) {

				jsonParser.nextToken();
				String contactEmail = jsonParser.getText();
				candidate.setEmail(contactEmail);

			} else if ("primaryEmail".equals(name)) {

				jsonParser.nextToken();
				String primaryEmail = jsonParser.getText();
				candidate.setEmail(primaryEmail);


			} else if ("applicationId".equals(name)) {

				jsonParser.nextToken();
				String applicationId = jsonParser.getText();
				map.put(SFCandidateConstants.SF_JOB_APPLICATION_ID,applicationId);
			} 
			else if("country".equals(name))
			{
				jsonParser.nextToken();
				String country = jsonParser.getText();
				if(country.equals("null"))
				{
					logger.info("Country is "+country+", Setting it to Australia");
					country = "Australia";
					map.put(SFCandidateConstants.CANDIDATECOUNTRY, country);
				}
				else
				{
					map.put(SFCandidateConstants.CANDIDATECOUNTRY, country);
				}
			}

			else if ("Revelian_Candidate_Id".equals(name)) {

				jsonParser.nextToken();
				String revelianCandidateId = jsonParser.getText();
				

				map.put(SFCandidateConstants.REVELIAN_CANDIDATE_ID, revelianCandidateId);
				

			}else if ("jobReqId".equals(name)) {

				jsonParser.nextToken();
				String jobReqId = jsonParser.getText();
				

				map.put(SFCandidateConstants.SF_JOB_REQ_ID, jobReqId);
				

			} else {
				
				jsonParser.nextToken();
			}
		}

		map.put(SFCandidateConstants.CANDIDATE_DETAILS, candidate);

		return map;
	}

	public static String parseRevelianCandidateResp(String response)throws JsonProcessingException, IOException 
	{
		JsonNode actualObj = new ObjectMapper().readTree(response);
		JsonNode positionIdNode = actualObj.get("id");
		String candidateId = positionIdNode.getTextValue();
		logger.info("Revelian candidate id: " + candidateId);
		return candidateId;
	}



	// Parse jobRequisition for Revelian Job Req Id

	public static Map<String, String> parseRequistionForPosition(JsonParser jsonParser,
			Map<String, String> map) throws JsonParseException, IOException {

		while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

			String name = jsonParser.getCurrentName();
			
			if ("d".equals(name)) {
				jsonParser.nextToken();
				
				parseRequistionForPosition(jsonParser, map);

			} else if ("revelian_position_id".equals(name)) {

				jsonParser.nextToken();
				String revlianPositionId = jsonParser.getText();
				map.put(SFCandidateConstants.REVELIAN_POSITION_ID, revlianPositionId);
				logger.info("encontered Revelian Position Id: " + revlianPositionId);
				break;
			} else {
				
				jsonParser.nextToken();
			}
		}

		return map;
	}
	
	
	
	/**
	 * 
	 * parses JSON response & Fetches application status id
	 * @param jsonParser
	 * @param map
	 * @return
	 * @throws JsonParseException
	 * @throws IOException
	 */
	public static Map<String, Object> parsingJsonForCandidateAppStatusId(JsonParser jsonParser, Map<String, Object> map) throws JsonParseException, IOException 
	{
		while (jsonParser.nextToken() != JsonToken.END_OBJECT) 
		{
			String name = jsonParser.getCurrentName();
			
			if("d".equals(name))
			{
				jsonParser.nextToken();
				parsingJsonForCandidateAppStatusId(jsonParser, map);
			}
			else if("appStatusId".equals(name))
			{
				jsonParser.nextToken();
				String appStatusId = jsonParser.getText();
				map.put(SFCandidateConstants.APPLICATION_STATUS_ID, appStatusId);
				logger.info("Application status id : "+appStatusId);
				break;
			}
			else
			{
				jsonParser.nextToken();
			}
		}
		return map;
	}
	
	
	/**
	 * 
	 * parses JSON response & Fetches application cadidate label and status label
	 * @param jsonParser
	 * @param map
	 * @return
	 * @throws JsonParseException
	 * @throws IOException
	 */
	public static Map<String, Object> parsingJsonForCandidateAppStatusLabel(JsonParser jsonParser, Map<String, Object> map) throws JsonParseException, IOException 
	{
		while (jsonParser.nextToken() != JsonToken.END_OBJECT) 
		{
			String name = jsonParser.getCurrentName();
			
			if("d".equals(name))
			{
				jsonParser.nextToken();
				parsingJsonForCandidateAppStatusLabel(jsonParser, map);
			}
			else if("candidateLabel".equals(name))
			{
				jsonParser.nextToken();
				String candidateLabel = jsonParser.getText();
				map.put(SFCandidateConstants.APPLICATION_CANDIDATE_LABEL, candidateLabel);
				logger.info("Application candidate label : "+candidateLabel);
				
			}
			else if("statusLabel".equals(name))
			{
				jsonParser.nextToken();
				String statusLabel = jsonParser.getText();
				map.put(SFCandidateConstants.APPLICATION_CANDIDATE_STATUS_LABEL, statusLabel);
				logger.info("Application status Label : "+statusLabel);
				
			}
			else
			{
				jsonParser.nextToken();
			}
		}
		return map;
	}

	
	/**
	 * @param response
	 * @return
	 * @throws JsonProcessingException
	 * @throws IOException
	 */
	public static Iterator<JsonNode> parseOrgAssessmentResp(String response)throws JsonProcessingException, IOException 
	{
		logger.info("response in parseRevelianIdResp :: "+response);
		JsonNode actualObj = new ObjectMapper().readTree(response);
		Iterator<JsonNode> nodeIterator = actualObj.getElements();
		logger.info("Got list of OrgAssessment: " + nodeIterator.hasNext());
		return nodeIterator;
	}
	
	public static String parseInvitationIdResp(String response)throws JsonProcessingException, IOException
	{
		JsonNode actualObj = new ObjectMapper().readTree(response);
		JsonNode positionIdNode = actualObj.get("id");
		String invitationId = positionIdNode.getTextValue();
		logger.info("Revelian candidate id: " + invitationId);
		return invitationId;
		
			
	}
	
	/**
	 * @param response
	 * @return
	 * @throws JsonProcessingException
	 * @throws IOException
	 */
	public static String parseRevelianOrgAssesmentResp(String response)throws JsonProcessingException, IOException 
	{
		JsonNode actualObj = new ObjectMapper().readTree(response);
		JsonNode orgAssessmentNode = actualObj.get("organizationAssessment");
		String orgAssessment = orgAssessmentNode.getTextValue();
		logger.info("Revelian organization Assessment : " + orgAssessment);
		return orgAssessment;
	}
	
	
}
