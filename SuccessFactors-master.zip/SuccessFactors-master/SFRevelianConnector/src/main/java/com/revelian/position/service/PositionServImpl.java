package main.java.com.revelian.position.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonFactory;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import main.java.com.revelian.candidate.model.Candidate;
import main.java.com.revelian.client.revelian.RevelianClient;
import main.java.com.revelian.client.successfactor.ConfigDetails;
import main.java.com.revelian.client.successfactor.SOAPClient;
import main.java.com.revelian.client.successfactor.SuccessFactorClient;
import main.java.com.revelian.position.model.Comparisons;
import main.java.com.revelian.position.model.Contact;
import main.java.com.revelian.position.model.Contacts;
import main.java.com.revelian.position.model.Position;
import main.java.com.revelian.position.model.Supervisor;
import main.java.com.revelian.position.util.SFJsonParsingUtil;
import main.java.com.revelian.position.util.SFMapConstants;
import main.java.com.revelian.position.util.XmlParsingUtil;

/**
 * This Class implements position service for creating position on revelian and update to sucessfactor.Also Update Score to Sucessfactor
 * @author Dipali.Rane
 *
 */
public class PositionServImpl implements PositionService {

	static Logger logger = Logger.getLogger(PositionServImpl.class);
	long scoreToBeConverted = 0;
	public String score = null;
	RevelianClient client = new RevelianClient();
	SuccessFactorClient successFactorClient = new SuccessFactorClient();
	SOAPClient soapclient = new SOAPClient();
	String POSITIONSCREATE = "positions";
	JSONParser parser = new JSONParser();
	Object obj;
	JSONObject jsonObject;
	JSONArray jsonArray;
	String candidateLink = "", candidateLoginUrl = "", result = "";
	/*public static Map<String, String> sfRevelianCandidateIdMap = new HashMap<String, String>();*/
	public static Map<String, String> sfRevelianStatusMap = new HashMap<String, String>();
	public static Map<String, String> revRevelianCandidateIdAndScoreMap = new HashMap<String, String>();
	public static Map<String, String> sfApplicationRevlianCandidateIdeMap = new HashMap<String, String>();
	String Rev_CandidateId = null;
	private String PREAPPROVED = "Pre-approved";
	private String APPROVED = "Approved";

	/*
	 * create position
	 */

	@Override
	public String createPosition(Position position)
	{
		String resp = null;
		try {
			resp = client.postDataToRevelian(POSITIONSCREATE, position);

			logger.info("Response==" + resp);
			logger.info((resp.isEmpty()) ? "Response is empty!" : "Position created successfully!");
			return resp;
		} catch (Exception e) {
			resp = "Error occurred while creating position. " + e.getMessage();

			logger.error("Error occurred while creating position" + e);
			return resp;

		}

	}

	/**
	 * //create candidates(positionId/candidate) to position
	 * 
	 * @param positionId
	 * @param candidate
	 */
	public String createCandidate(String positionId, Candidate candidate) {

		try {
			String resp = client.postDataToRevelian("positions" + "/" + positionId + "/" + "candidates", candidate);
			logger.info((resp.isEmpty()) ? "Response is empty!" : "Candidate created successfully!");
			return resp;
		} catch (Exception e) {
			logger.error("Error occurred while creating Candidate" + e);

		}
		return null;
	}

	/**
	 * This method performs task of Parsing SF event Xml Data.
	 * 
	 * @param -
	 * xml Data obtained from SF events
	 * @return position id
	 */
	@Override
	public String createPositionInRevelian(String xmlMessage) {

		Position position = null;
		String positionId = null;
		String State=null;
		String location=null;
		String country=null;
	
		try {
			// get requisition id from xml
			String jobReqId = parseJobReqEvent(xmlMessage);
			logger.info("JobRequisitionId="+jobReqId);
			if (jobReqId != null && !jobReqId.isEmpty()) 
			{
				String jobRegDetails = "";
				String jobReqLocalResponse = "";
				String jobRecuiterResponse = "";
				String jobReqStateDetails="";
				// get job requisition details from SF
				jobRegDetails = successFactorClient.getDataFromSuccessFactors("JobRequisition(" + jobReqId + ")");
				if (!jobRegDetails.isEmpty()) 
				{
					Map<String, String> map = new HashMap<String, String>();
					//get State From Requisition Data
					jobReqStateDetails=successFactorClient.getDataFromSuccessFactors("JobRequisition(" + jobReqId + ")/state");
					map= SFJsonParsingUtil.parseJobRequistionStateDetails(new JsonFactory().createJsonParser(jobReqStateDetails), map);
					//get RevlianPositionId,Location ,Country From SF JobRequistion
					map = SFJsonParsingUtil.parseJobRequistionDetails(new JsonFactory().createJsonParser(jobRegDetails), map);
					String revelianPositionId= map.get(SFMapConstants.REVELIAN_POSITION_ID);
					State=map.get(SFMapConstants.STATE);
					logger.info("State = "+State);
					location=map.get(SFMapConstants.LOCATION);
					logger.info("location = "+location);
					country=map.get(SFMapConstants.COUNTRY);
					logger.info("country = "+country);
					logger.info("RevelianpositionId for requsition= " + jobReqId + " is = " + revelianPositionId);
					
					if(!revelianPositionId.equals("null") && revelianPositionId!=null && !revelianPositionId.isEmpty())
					{
						logger.info("Revelian PositioId="+revelianPositionId);
						positionId = "-1";
					}
					else
					{
						jobReqLocalResponse = successFactorClient.getDataFromSuccessFactors("JobRequisition(" + jobReqId + ")/jobReqLocale");
						jobRecuiterResponse = successFactorClient.getDataFromSuccessFactors("JobRequisition(" + jobReqId + ")/recruiter");

						if (!jobReqLocalResponse.isEmpty() && !jobRecuiterResponse.isEmpty())
						{
							position = parsejobReqLocalRecuiterData(jobReqLocalResponse, jobRecuiterResponse);
							if((!location.equals("null") && !(location.isEmpty())&& (!country.equals("null") && !(country.isEmpty())) && (!State.equals("null") && !(State.isEmpty()))))
							{
								logger.info("==================== Sending jobreq Id: "+jobReqId+" to create postionon revelian method");
								positionId = createPostionOnRevelian(position, jobReqId);
								if (positionId != null && !positionId.equals(null))
								{
									// ==============completionURL======//
									 Properties properties=new ConfigDetails().readPropertiesFileDetails("RevelianDetails.properties");
									 String connectorpath=properties.getProperty("ConnectorURL");
									 String compltionURL=connectorpath+"/SFRevelianConnector/rest/position/score/"+positionId+"/$candidateId";
									 logger.info("Completion Url : "+compltionURL);
									 position.setId(positionId);
									 position.setCompletionUrl(compltionURL);
									// position.setTitle(jobTitle);
									 String url="positions/"+positionId;
									 client.updateDataToRevelian(url, position);
									 updateSFCustomPosId(positionId, jobReqId);
									  logger.info("Position updated successfully!");
									 updateSFCustomAssmentLink(positionId, jobReqId);
									 logger.info("After Update Revelian PositionID and AssessmentLink::"+positionId);
								 }
							}
							else
							{
								logger.info("Position Not Cretaed In Revelian Because Location,State,Country are null.");
								positionId = "0";
							}
						}
						else 
						{
							logger.info("jobReqLocalResponse or jobRecuiterResponse is empty");
						}
					}
				}
				else {
					logger.error("Error occured while parsing  requisition details.");
					//throw new RuntimeException("Error - requisition Id not found in xml or Xml parsing error.");
				}
			} 
			else {
				logger.error("Error occured while parsing event xml data or requisition id not present in xml data.");
				//throw new RuntimeException("Error - requisition Id not found in xml or Xml parsing error.");
			}
		} catch (IOException e) {
			logger.error("Error occured while pasring SF event data or Getting(Parsing) Requistion detials from SF ODATA API. Error : ",e);
		}
		return positionId;
	}

	/**
	 * This method will call method from XmlParsingUtility class to parse the
	 * New Job Requisition SF event Xml response
	 * 
	 * @param xmlMessage
	 * @return Job Requisition Id
	 */
	private String parseJobReqEvent(String xmlMessage) {

		String jobReqId = XmlParsingUtil.parseJobRequisitionXmlData(xmlMessage);
		logger.info("Job Requistion Id from parsing event xml response: " + jobReqId);
		return jobReqId;
	}

	/**
	 * This method calls SFJsonParsingUtil class different methods to parse
	 * ODATA API Json Response to get job Requisition, and Position Details
	 * which is required to create position is revelian.
	 * 
	 * @param jobRecuiterResponse
	 * @param jobReqLocalResponse
	 * @param response
	 * @return Position to be created on Revelain.
	 * @throws JsonProcessingException
	 * @throws IOException
	 */
	private Position parsejobReqLocalRecuiterData(String jobReqLocalResponse, String jobRecuiterResponse)
			throws JsonProcessingException, IOException {

		logger.info(" In parseRequisitionJsonDatafromSF Parsing JSON response obtained from ODATA API");
		Map<String, String> map = new HashMap<String, String>();

		SFJsonParsingUtil parsingUtil = new SFJsonParsingUtil();
		// Get job requisition recruiter details
		JsonParser jsonParser = new JsonFactory().createJsonParser(jobRecuiterResponse);
		map = parsingUtil.parseJobRequistionRecruiter(jsonParser, map);
		// Get job title
		jsonParser = new JsonFactory().createJsonParser(jobReqLocalResponse);
		map = parsingUtil.getJobRequistionTitle(jsonParser, map);
		logger.info("After parsing SF ODATA API Job Requisition Title is: "+ map.get(SFMapConstants.REQUISITION_JOB_TITLE));
		Position position = createPositionObject(map);
		logger.info("Position Object Obtained from json data: " + position);
		return position;
	}

	
	/**
	 * This method uses all the parsed Json Data obtained in map to create
	 * Position Object.
	 * 
	 * @param map
	 * @param position
	 */

	private Position createPositionObject(Map<String, String> map) {

		Position position = new Position();
		final String DEFAULT_POSITION_JOB_CATEGORY = "OTHER";
		final String DEFAULT_POSITION_MANAGEMENT_LEVEL = "NONE";
		position.setTitle(map.get(SFMapConstants.REQUISITION_JOB_TITLE));
		logger.info("PositionTitle = " + map.get(SFMapConstants.REQUISITION_JOB_TITLE));
		Contact contact = new Contact();
		Supervisor supervisor = new Supervisor();
		Contacts contacts = new Contacts();

		contact.setName(map.get(SFMapConstants.CONTACT_NAME));
		contact.setEmail(map.get(SFMapConstants.CONTACT_EMAIL));
		contact.setPhone(map.get(SFMapConstants.CONTACT_PHONE));
		contact.setPosition(map.get(SFMapConstants.CONTACT_POSITION));
		contact.setMobile(map.get(SFMapConstants.CONTACT_MOBILE));
		contacts.setContact(contact);
		contacts.setSupervisor(supervisor);

		position.setContacts(contacts);

		Comparisons comparisons = new Comparisons();
		comparisons.setJobCategory(DEFAULT_POSITION_JOB_CATEGORY);
		comparisons.setManagementLevel(DEFAULT_POSITION_MANAGEMENT_LEVEL);
		position.setComparisons(comparisons);
		return position;
	}

	/**
	 * This method calls actual createPosition revelian POST API to create
	 * position on Revelian. It gives revelian positionId.
	 * 
	 * @param position,
	 *            jobReqId
	 * @throws IOException
	 * @throws JsonProcessingException
	 */
	private String createPostionOnRevelian(Position position, String jobReqId)
			throws JsonProcessingException, IOException {

		logger.info("In createPostionOnRevelian,  Now calling createPosition of Revelian for position: " + position);
		String resp = null;
		String positionId = null;
		try {
			resp = client.postDataToRevelian(POSITIONSCREATE, position);
			logger.info("Response==" + resp);
			logger.info((resp.isEmpty()) ? "Response is empty!" : "Position created successfully!");
			if (!resp.isEmpty()) {
				ObjectMapper mapper = new ObjectMapper();
				JsonNode actualObj = mapper.readTree(resp);
				JsonNode positionIdNode = actualObj.get("id");
				positionId = positionIdNode.getTextValue();
				logger.info("Obtained position id after creating on revelian: " + positionId);
				logger.info("In createPostionOnRevelian, Position Id obtained after creating of position on Revelian: "
						+ positionId + ", mapped to requisition Id: " + jobReqId);
			}
		} catch (Exception e) {
			resp = "Error occurred while creating position. " + e.getMessage();
			logger.error("Error occurred while creating position" + e);
			return resp;
		}
		return positionId;
	}

	/**
	 * Update SF Position Id custom field
	 * 
	 * @param posId
	 * @param jobReqId
	 * @return
	 */
	private String updateSFCustomPosId(String posId, String jobReqId) {

		logger.info("In updateSFCustomPosId");
		return successFactorClient.sendDataToSF(jobReqId, "revelian_position_id", posId, "JobRequisition");
	}

	/**
	 * Update SF custom field Assessment Link
	 * 
	 * @param posId
	 * @param jobReqId
	 * @return
	 */
	private String updateSFCustomAssmentLink(String posId, String jobReqId) {

		logger.info("In updateSFCustomAssmentLink");
		String StagingURL = "<p><a href=\"https://staging.revelian.com/workspace/public_api_assessment_configuration.cfm?apiKey=1VIN5R8eifFYP1Dk&positionId=";
		String redirectTo = "&redirectTo=https://www.google.com\" target=\"_blank\">Revelian_Assessment Link</a></p>";
		String assessmentLink = StagingURL + posId + redirectTo;
		logger.info("AssessmentLink = " + assessmentLink);
		return successFactorClient.sendDataToSF(jobReqId, "revelianAssessmentLink", assessmentLink, "JobRequisition");
	}

}
