package main.java.com.revelian.client.revelian;

import java.net.URI;
import java.util.Properties;
import javax.ws.rs.core.UriBuilder;
import org.apache.log4j.Logger;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import main.java.com.revelian.client.successfactor.ConfigDetails;
import main.java.com.revelian.errorstatus.model.ErrorStatus;
import main.java.com.revelian.errorstatus.util.ErrorParsing;
import sun.misc.BASE64Encoder;

/**
 *This is class calls Revlian API.
 * 
 * @author ketaki
 *
 */
public class RevelianClient {

	static Logger logger = Logger.getLogger(RevelianClient.class);
	String authString = getRevelianUserName() + ":" + getRevelianPassword();// TO DO
	String authStringEnc = new BASE64Encoder().encode(authString.getBytes());
	static String baseURL=null;
    
	Client client = Client.create();
	String EMPTY = "";
	String response = EMPTY;
	  
	 String  revelianUserName;
	 String  revelianPassword;
	 static String  revelianBaseURL;
	 static String  revelianBaseURLVersion;
	 static Properties properties=new ConfigDetails().readPropertiesFileDetails("RevelianDetails.properties");
	/**
	 * This method calls Revelian API 'positions' to create position.
	 * 
	 * @param position
	 *            - position to be created
	 */
	public String postDataToRevelian(String URL, Object postData) {
		String response = EMPTY;
		try {
			logger.info("URL - " + URL + " Post data - " + postData.toString());
			
			WebResource webResource = client.resource(getBaseURI()).path(URL);
			
			ClientResponse resp = webResource.accept("application/json")
					.header("Authorization", "Basic " + authStringEnc).header("Content-type", "application/json")
					.post(ClientResponse.class, postData);
			if (resp.getStatus() != 201)
			{
				String res=resp.getEntity(String.class);
				logger.error("Error response: "+resp.getStatus()+" " + res);
				ErrorStatus status=ErrorParsing.errorResponseParse(res);
                String Message=status.getMessage();
                logger.info("Message="+Message);
				
			}
			response = resp.getEntity(String.class);
			logger.info(response);
		} catch (Exception e) {
			logger.error("Error occurred: " + e);
		}
		return response;
	}

	public String updateDataToRevelian(String URL,Object postData) {
		String response = EMPTY;
		try 
		{
			logger.info("URL - " + URL + " Post data - " + postData.toString());
			WebResource webResource = client.resource(getBaseURI()).path(URL);
			ClientResponse resp = webResource.accept("application/json")
					.header("Authorization", "Basic " + authStringEnc).header("Content-type", "application/json")
					.put(ClientResponse.class, postData);
			if (resp.getStatus() != 200)
			{
				String res=resp.getEntity(String.class);
				logger.error("Error response: "+resp.getStatus()+" " + res);
				ErrorStatus status=ErrorParsing.errorResponseParse(res);
                String Message=status.getMessage();
			}
			response = resp.getEntity(String.class);
			logger.info(response);
		} catch (Exception e) {
			logger.error("Error occurred: " + e);
		}
		return response;
	}

	/**
	 *This method calls Revelian API to get relevant data from Revelian
	 * 
	 * @param positionId
	 */
	public String getDataFromRevelian(String URL)
	{
		String response = EMPTY;
		try 
		{
			logger.info("URL="+URL);
			String url=getBaseURI()+URL;
			WebResource webResource = client.resource(url);
			logger.info("Resource URL="+webResource.toString());
			ClientResponse resp = webResource.accept("application/json")
					.header("Authorization", "Basic " + authStringEnc).get(ClientResponse.class);
			 if (resp.getStatus() != 200) 
			  {
			    		logger.error("Error response: " + resp.getEntity(String.class));
			    		throw new RuntimeException("Failed : HTTP error code : " + resp.getStatus());
			   }
			   return response = resp.getEntity(String.class);
		} 
		catch (Exception e) {
			logger.error("Error occurred: " + e);
		}
		return response;
	}
   
    
	/**
	 * This Method Gives Base URI for Revelian
	 * @return
	 */
	private static URI getBaseURI() 
	{
		
		String companyuri =  getRevelianBaseURL() +"/"+getRevelianBaseURLVersion();
		return UriBuilder.fromUri(companyuri).build();
	}
	
	public String getRevelianUserName() 
	{
		
		revelianUserName=properties.getProperty("UserName");
		return revelianUserName;
	}
	public String getRevelianPassword() {
		
		revelianPassword=properties.getProperty("Password");
		return revelianPassword;
	}
	public static String getRevelianBaseURL() {
		
		revelianBaseURL=properties.getProperty("BaseURL");
		
		return revelianBaseURL;
	}
	public static String getRevelianBaseURLVersion() {
		
		revelianBaseURLVersion=properties.getProperty("Version");
		
		return revelianBaseURLVersion;
	}
}
