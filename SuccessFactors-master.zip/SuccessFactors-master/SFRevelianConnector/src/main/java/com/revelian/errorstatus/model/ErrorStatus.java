package main.java.com.revelian.errorstatus.model;

public class ErrorStatus
{
  private String conversationId;
  private String code;
  private String message;
  public String getConversationId() {
	return conversationId;
}
public void setConversationId(String conversationId) {
	this.conversationId = conversationId;
}
public String getCode() {
	return code;
}
public void setCode(String code) {
	this.code = code;
}
public String getMessage() {
	return message;
}
public void setMessage(String message) {
	this.message = message;
}


 
}
