package main.java.com.revelian.invitation.model;

public class InvitationforPosition 
{
	private String invitationId;
	private String candidateId;
	private String orgAssessment;
	private String expiryDate;
	private String type;
	private String status;
	private String candidateLoginUrl;
	private String created;
	
	
	public String getInvitationId() {
		return invitationId;
	}
	public void setInvitationId(String invitationId) {
		this.invitationId = invitationId;
	}
	public String getCandidateId() {
		return candidateId;
	}
	public void setCandidateId(String candidateId) {
		this.candidateId = candidateId;
	}
	public String getOrgAssessment() {
		return orgAssessment;
	}
	public void setOrgAssessment(String orgAssessment) {
		this.orgAssessment = orgAssessment;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCandidateLoginUrl() {
		return candidateLoginUrl;
	}
	public void setCandidateLoginUrl(String candidateLoginUrl) {
		this.candidateLoginUrl = candidateLoginUrl;
	}
	public String getCreated() {
		return created;
	}
	public void setCreated(String created) {
		this.created = created;
	}
	
	
	
}
