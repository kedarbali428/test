package main.java.com.revelian.position.model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Position {
	String Id;
	String title;
	Contacts contacts;
	Comparisons comparisons;
    String completionUrl;
	
	public Position() {

	}

	public Position(String title, Contacts contacts, Comparisons comparisons) {

		this.title = title;
		this.contacts = contacts;
		this.comparisons = comparisons;
	}
	public Position(String title, Contacts contacts, Comparisons comparisons,String completionURL) {

		this.title = title;
		this.contacts = contacts;
		this.comparisons = comparisons;
		this.completionUrl=completionURL;
	}
	public Position(String id, String title, Contacts contacts, Comparisons comparisons,String completionURL) {

		Id = id;
		this.title = title;
		this.contacts = contacts;
		this.comparisons = comparisons;
		this.completionUrl=completionURL;
	}

	public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}

	public String getTitle() {
		return title;
	}

	@XmlElement
	public void setTitle(String title) {
		this.title = title;
	}

	public Contacts getContacts() {
		return contacts;
	}

	@XmlElement
	public void setContacts(Contacts contacts) {
		this.contacts = contacts;
	}

	public Comparisons getComparisons() {
		return comparisons;
	}

	@XmlElement
	public void setComparisons(Comparisons comparisons) {
		this.comparisons = comparisons;
	}
	public String getCompletionUrl() {
		return completionUrl;
	}
	@XmlElement
	public void setCompletionUrl(String completionUrl) {
		this.completionUrl = completionUrl;
	}

	@Override
	public String toString() {
		return "Position [Id=" + Id + ", title=" + title + ", contacts=" + contacts + ", comparisons=" + comparisons+", completionURL="+
				completionUrl+ "] ";
	}

}
