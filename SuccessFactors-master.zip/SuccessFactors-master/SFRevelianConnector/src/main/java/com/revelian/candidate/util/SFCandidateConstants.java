package main.java.com.revelian.candidate.util;

public class SFCandidateConstants 
{
	public static final String CANDIDATE_DETAILS = "CandidateDetails";
   
   	public static final String SF_JOB_REQ_ID = "SFJobRequisitionId";

	public static final String REVELIAN_POSITION_ID="Revelian Position Id";
	
	public static final String REVELIAN_CANDIDATE_ID="Revelian Candidate Id";
	
	public static final String SF_JOB_APPLICATION_ID="SFCandidateJobApplicationId";
	
	public static final String SF_CANDIDATE_ID="SFCandidateId";
	
	public static final String APPLICATION_STATUS_ID = "Application Status Id";
	
	public static final String APPLICATION_CANDIDATE_LABEL = "Application Candidate Label";
	
	public static final String APPLICATION_CANDIDATE_STATUS_LABEL = "Application Candidate Status Label";
	
	public static final String CANDIDATECOUNTRY = "COUNTRY";
}
