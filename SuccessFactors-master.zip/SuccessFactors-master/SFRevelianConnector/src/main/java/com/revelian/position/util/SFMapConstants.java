package main.java.com.revelian.position.util;

public class SFMapConstants {
	

	
	public static final String SF_JOB_REQ_ID = "SFJobRequisitionId";

	public static final String REQUISITION_JOB_TITLE = "JobTitle";

	public static final String CONTACT_POSITION = "Operator Role";

	public static final String CONTACT_LASTNAME = "Last Name";
	
	public static final String CONTACT_FIRSTNAME = "First Name";
	
	public static final String CONTACT_EMAIL = "Email";
	
	public static final String CONTACT_NAME = "Full Name";
	
	public static final String CONTACT_PHONE = "Phone Number";
	
	public static final String CONTACT_MOBILE = "Mobile Number";
	
	public static final String INETRNAL_STATUS = "Internal Status";
	
	public static final String REVELIAN_POSITION_ID="Revelian Position Id";
	
	public static final String REVELIAN_CANDIDATE_ID="Revelian Candidate Id";
	
	public static final String SF_JOB_APPLICATION_ID="SFCandidateJobApplicationId";
	
	public static final String LOCATION="location";
	public static final String STATE="state";
	public static final String COUNTRY="country";
	
	/*public static final String SF_CANDIDATE_ID="SFCandidateId";*/
	

}
