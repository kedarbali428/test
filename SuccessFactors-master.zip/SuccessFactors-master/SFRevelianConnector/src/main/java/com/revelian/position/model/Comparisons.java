package main.java.com.revelian.position.model;

public class Comparisons {
	String jobCategory;
	String managementLevel;

	public Comparisons() {

	}

	public Comparisons(String jobCategory, String managementLevel) {

		this.jobCategory = jobCategory;
		this.managementLevel = managementLevel;
	}

	public String getJobCategory() {
		return jobCategory;
	}

	public void setJobCategory(String jobCategory) {
		this.jobCategory = jobCategory;
	}

	public String getManagementLevel() {
		return managementLevel;
	}

	public void setManagementLevel(String managementLevel) {
		this.managementLevel = managementLevel;
	}

	@Override
	public String toString() {
		return "Comparisons [jobCategory=" + jobCategory + ", managementLevel=" + managementLevel + "]";
	}
}
