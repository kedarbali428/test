package main.java.com.revelian.position.model;

public class Contact {

	String name;
	String email;
	String position;
	String phone;
	String mobile;

	public Contact() {

	}

	public Contact(String name, String email, String position, String phone, String mobile) {
		super();
		this.name = name;
		this.email = email;
		this.position = position;
		this.phone = phone;
		this.mobile = mobile;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	@Override
	public String toString() {
		return "Contact [name=" + name + ", email=" + email + ", position=" + position + ", phone=" + phone
				+ ", mobile=" + mobile + "]";
	}

}
