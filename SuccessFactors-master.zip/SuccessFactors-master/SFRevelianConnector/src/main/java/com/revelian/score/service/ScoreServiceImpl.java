package main.java.com.revelian.score.service;

import java.util.HashMap;
import java.util.Map;
import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import main.java.com.revelian.client.revelian.RevelianClient;
import main.java.com.revelian.client.successfactor.SuccessFactorClient;

public class ScoreServiceImpl implements ScoreService {
	static Logger logger = Logger.getLogger(ScoreServiceImpl.class);
	RevelianClient client = new RevelianClient();
	SuccessFactorClient successFactorClient = new SuccessFactorClient();

	JSONParser parser = new JSONParser();

	/*
	 * 
	 * Score
	 * 
	 * */


	/* 
	 * This Method get candidate Result from Revelian and Update that result to sucessfactor
	 * 
	 */
	@Override
	public String updateCandidateScoreToRevelian(String positionId,String candidateId) 
	{
		String output=null;
		JsonNode outputfromSF=null;
		String message=null;
		String applicationId = getApplicationIDFromSF(candidateId);
		logger.info("ApplcatioNID="+applicationId);
		try {
		String response=client.getDataFromRevelian("/positions/"+positionId+"/results?candidate="+candidateId);
		if(!response.isEmpty())
		{
			Map<String,String> result=parseCandidateResult(response);
			output = updateScoreToSucessFactor(applicationId,result);
			ObjectMapper mapper = new ObjectMapper();
			JsonNode root = mapper.readTree(output);
			outputfromSF = root.path("d");
			if(outputfromSF.isMissingNode())
			{
				logger.info("REsult Not Created");
			}
			else
			{
				for (JsonNode node : outputfromSF)
				{
					message=node.path("message").getTextValue();
					logger.info("Message From SucessFactor = "+message);
				}
				logger.info("message::::: " + message);
			}
		}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		}
		return message;
	}
	/**
	 * This Method gets Candidate JobApplicationId from sucessfactor using RevelianCandidateId
	 * @param candidateId
	 * @return
	 */
	public String getApplicationIDFromSF(String candidateId) 
	{
		String applicationId="";
		String result="";
		try 
		{
			logger.info("CandidateId in getApplicationIDFromSF = " + candidateId);
			String url="JobApplication?$filter=Revelian_Candidate_Id%20eq%20'"+candidateId+"'";
			result = successFactorClient.getDataFromSuccessFactors(url);
			logger.info("result in getApplicationIDFromSF : " + result);
			JSONParser parser = new JSONParser();
			Object obj = parser.parse(result);
			JSONObject jSONObject = (JSONObject) obj;
			JSONObject jsonObject1 = (JSONObject) jSONObject.get("d");
			JSONArray results = (JSONArray) jsonObject1.get("results");

			for (Object number : results) 
			{
				JSONObject jsonArrayObject = (JSONObject) number;
				applicationId = (String) jsonArrayObject.get("applicationId");
				logger.info("applicationId: " + applicationId);
			}

		}
		catch (ParseException e) {
			logger.error(e.getMessage());
		}
		return applicationId;
	}

	/**
	 * This Method Update the Score And returnUrl to Sucessfactor
	 * @param applicationId
	 * @param result
	 * @return
	 */
	public String updateScoreToSucessFactor(String  applicationId,Map<String, String> result) {

		String score=null;
		String reporturl=null;
		String output = null;

		for (Map.Entry<String,String> entry : result.entrySet()) 
		{

			score=entry.getKey();
			reporturl=entry.getValue();
		}
		logger.info("percentile="+score);
		logger.info("reportUrl="+reporturl);
		logger.info("jobApplicationId=" + applicationId);
		//update Score
		output = successFactorClient.sendDataToSF(applicationId, "Assesement_Score",score, "JobApplication");
		//update reportUrl		
		String finalReportURL="[Report Link]["+reporturl+"]";
		output = successFactorClient.sendDataToSF(applicationId, "reportUrl",finalReportURL, "JobApplication");


		return output;
	}

	/**
	 * parse candidate  result  response  which gets from Revelian
	 * @param response
	 * @return
	 */
	public Map<String, String> parseCandidateResult(String response)
	{
		JsonNode candidateNode;
		JsonNode suitability;
		String score = null;
		String reportUrl=null;

		Map<String,String> candidateResult=new HashMap<String,String>();
		try 
		{
			ObjectMapper mapper = new ObjectMapper();
			JsonNode root = mapper.readTree(response);
			candidateNode = root.path("candidates");
			if(candidateNode.isMissingNode())
			{
				logger.info("Candidate not found or null");
			}
			else
			{
				for (JsonNode node : candidateNode)
				{
					reportUrl=node.path("reportUrl").getTextValue();
					logger.info("reportUrl = "+reportUrl);
					suitability=node.path("suitability");
					if(suitability.isMissingNode())
					{
						logger.info("Score Not generated.");
					}
					else
					{
						score=suitability.path("score").getValueAsText();
						logger.info("Score::::: " + score);
					}
				}
				logger.info("Score::::: " + score);
			}
			candidateResult.put(score, reportUrl);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		}
		return candidateResult;
	}


}
