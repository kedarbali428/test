package main.java.com.revelian.invitation.util;

public class SFInvitationConstants 
{
	public static final String EMAIL_SENT_SUCCESS = "Email Sent Successfully";
	
	public static final String EMAIL_SENT_FAILURE = "Email Not Sent Successfully";
	
	public static final String ORGANIZATION_ASSESSMENT = "Organization Assesssment";

}
