package main.java.com.revelian.errorstatus.util;

import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;
import main.java.com.revelian.errorstatus.model.ErrorStatus;

public class ErrorParsing 
{
	static Logger logger = Logger.getLogger(ErrorParsing.class);
	
	   public static ErrorStatus errorResponseParse(String response)
	   {
		   logger.info("Response=="+response);
		   String conversationId=null;
		   String code=null;
		   String message=null;
		   ErrorStatus status=null;
		   try {

				ObjectMapper mapper = new ObjectMapper();
				 JsonNode root = mapper.readTree(response);
				 
				 /*conversationId = root.path("conversationId").getTextValue();
				 code=root.path("conversationId").getTextValue();
				 message=root.path("conversationId").getTextValue();*/
				status = mapper.readValue(response, ErrorStatus.class);
				


			} catch (Exception e) {
				// TODO Auto-generated catch block
				logger.error(e.getMessage());
			}
             return status;
		   
		   
		   
		
		   
	   }
}
