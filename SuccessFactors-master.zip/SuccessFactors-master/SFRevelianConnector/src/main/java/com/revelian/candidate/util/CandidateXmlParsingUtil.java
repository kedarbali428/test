package main.java.com.revelian.candidate.util;


import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

/**
 * This class is mainly concerned with Parsing xml data obtained from SF events.
 * 
 * @author Dipali.Rane
 *
 */
public class CandidateXmlParsingUtil {

	static Logger logger = Logger.getLogger(CandidateXmlParsingUtil.class);
	static String CANDIDATE_ID_STRING = "candidateId";
	static String APPLICATION_ID_STRING = "applicationId";
	static String JOB_REQUISITION_ID_STRING = "jobReqId";
	static String EVENT_TAG = "event";
	static String PARAM_TAG = "param";
	static String ENTITY_KEY_TAG = "entityKey";
	static String NAME_TAG = "name";
	static String VALUE_TAG = "value";
	static String SOAP_BODY_TAG = "S:Body";
	static String EXTERNAL_EVENT = "ExternalEvent";
	static String CREATERCMASSESSMENTREQUEST = "createRcmAssessmentRequest";
	static String ENTITY_KEY = "entityId";
	
	
	
	/**
	 * Parse The Candidate XMl request from sucessfactor for create candidate
	 * @param xmlData
	 * @return
	 */
	public static String parseCandidateXmlData(String xmlData) 
	{
		String entityId = null;
		String extractPrefix = "";
		try 
		{
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(new InputSource(new StringReader(xmlData)));
			doc.getDocumentElement().normalize();
			/*Element rootElement = doc.getDocumentElement();*/
			NodeList soapBodyList = doc.getElementsByTagName(SOAP_BODY_TAG);
			NodeList bodyChildList = soapBodyList.item(0).getChildNodes();

			for (int i = 0; i < bodyChildList.getLength(); i++) {

				Node nNode = bodyChildList.item(i);
				if (nNode.getNodeType() == Node.ELEMENT_NODE && nNode.getNodeName().contains(CREATERCMASSESSMENTREQUEST)) 
				{
					extractPrefix = nNode.getNodeName().split(":")[0];
					extractPrefix = extractPrefix + ":";
					logger.info("Prefix obtained is:" + extractPrefix);
					break;
				}

			}

			for (int temp = 0; temp < soapBodyList.getLength(); temp++) {
				Node nNode = soapBodyList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					entityId = eElement.getElementsByTagName(extractPrefix + ENTITY_KEY).item(0).getTextContent();
					logger.info("entityId::"+entityId);

				}
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return entityId;

	
	}
	
	
	
	
	
	
	/**
	 * This method Parse XML Response From Sucessfactor(Candidate Response)
	 * @param xmlData
	 * @return entityId
	 */
	public static String parseCandidateXmlDataForStatus(String xmlData) 
	{

		String entityId = null;
		String extractPrefix = "";
		try 
		{
			
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(new InputSource(new StringReader(xmlData)));
			doc.getDocumentElement().normalize();
			/*Element rootElement = doc.getDocumentElement();*/
			NodeList soapBodyList = doc.getElementsByTagName(SOAP_BODY_TAG);
			NodeList bodyChildList = soapBodyList.item(0).getChildNodes();

			for (int i = 0; i < bodyChildList.getLength(); i++) {

				Node nNode = bodyChildList.item(i);
				if (nNode.getNodeType() == Node.ELEMENT_NODE && nNode.getNodeName().contains(CREATERCMASSESSMENTREQUEST)) 
				{
					extractPrefix = nNode.getNodeName().split(":")[0];
					extractPrefix = extractPrefix + ":";
					logger.info("Prefix obtained is:" + extractPrefix);
					break;
				}

			}

			for (int temp = 0; temp < soapBodyList.getLength(); temp++) {
				Node nNode = soapBodyList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					entityId = eElement.getElementsByTagName(extractPrefix + ENTITY_KEY).item(0).getTextContent();
					logger.info("entityId::"+entityId);

				}
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return entityId;

	}

	
}
