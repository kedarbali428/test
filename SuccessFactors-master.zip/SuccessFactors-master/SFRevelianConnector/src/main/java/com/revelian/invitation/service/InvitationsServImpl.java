package main.java.com.revelian.invitation.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonFactory;
import org.codehaus.jackson.JsonNode;

import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.JsonProcessingException;
import org.json.simple.parser.JSONParser;


import main.java.com.revelian.candidate.service.CandidateServImpl;
import main.java.com.revelian.candidate.util.SFCandidateConstants;
import main.java.com.revelian.candidate.util.SFCandidateJsonParsingUtil;
import main.java.com.revelian.client.revelian.RevelianClient;
import main.java.com.revelian.client.successfactor.SOAPClient;
import main.java.com.revelian.client.successfactor.SuccessFactorClient;
import main.java.com.revelian.invitation.model.CandidateDetailsforInvitation;
import main.java.com.revelian.invitation.model.InvitationEmail;
import main.java.com.revelian.invitation.model.InvitationforPosition;
import main.java.com.revelian.invitation.model.Invitations;
import main.java.com.revelian.invitation.util.SFInvitationConstants;
import main.java.com.revelian.invitation.util.SFInvitationJsonParsingUtil;
import main.java.com.revelian.score.service.ScoreServiceImpl;


/**
 * 
 * This class used For send test invitation to Candidate
 * @author Dipali.Rane
 *
 */
public class InvitationsServImpl implements InvitationService {

	static Logger logger = Logger.getLogger(InvitationsServImpl.class);
	RevelianClient client = new RevelianClient();
	SuccessFactorClient successFactorClient = new SuccessFactorClient();
	SOAPClient soapclient = new SOAPClient();
	JSONParser parser = new JSONParser();
	private CandidateServImpl candidateService = new CandidateServImpl();
	private ScoreServiceImpl scoreService = new ScoreServiceImpl();

	/**
	 * This method returns performs task of Parsing SF event Xml Data, Call
	 * ODATA API to get candidate application Details, fetches appStatusId and candidateLabel.
	 * 
	 * @author Sayali.Parkhi
	 * @param -
	 *            xml Data obtained from SF events
	 */

	public Object sendCandidateInvitation(String candidateId)
	{
		logger.info(" In sendCandidateInvitation method");
		logger.info("Candiate Id in sendCandidateInvitation : "+candidateId);
		String candidateLabel = null;
		String statusLabel = null;
		String applicationId = null;
		String invitationId = null;
		String revelianPositionId = null;
		String revelianCandidateId = null;
		Map<String, Object> map = null;
		List<String> listOrgAssessment = null;
		String responseForJobAppStatus = "";
		InvitationEmail forEmail = new InvitationEmail();
		try
		{
			applicationId = scoreService.getApplicationIDFromSF(candidateId);
			logger.info("Application Id in sendCandidateInvitation : "+applicationId);
			map = getRevelianDetails(applicationId,map);
			revelianCandidateId = (String) map.get(SFCandidateConstants.REVELIAN_CANDIDATE_ID);
			revelianPositionId = (String) map.get(SFCandidateConstants.REVELIAN_POSITION_ID);
			logger.info("Fetched Revelian Candidate Id : "+revelianCandidateId+" and Revelian Position Id : "+revelianPositionId);
			responseForJobAppStatus = successFactorClient.getDataFromSuccessFactors("JobApplication(" + applicationId + ")/jobAppStatus");
			if (!responseForJobAppStatus.isEmpty()) 
			{
				map = parseCandidateAppStatusIdFromSF(responseForJobAppStatus);
				String appStatusId = (String) map.get(SFCandidateConstants.APPLICATION_STATUS_ID);
				logger.info("APPLICATION STATUS ID = " + appStatusId);
				if(appStatusId != null && !appStatusId.isEmpty())
				{
					String responseforStatusLabel = successFactorClient.getDataFromSuccessFactors("JobApplicationStatus("+appStatusId+")/jobAppStatusLabel");
					if (!responseforStatusLabel.isEmpty())
					{
						map = parseCandidateAppStatusLabelFromSF(responseforStatusLabel);
						candidateLabel = (String) map.get(SFCandidateConstants.APPLICATION_CANDIDATE_LABEL);
						statusLabel = (String) map.get(SFCandidateConstants.APPLICATION_CANDIDATE_STATUS_LABEL);
						logger.info("Fetched Candidate Label = " + candidateLabel + " and Status Label "+statusLabel);
					}

				}
				else 
				{
					logger.info("Error occured while parsing job application status Id.");
				}

			}
			else 
			{
				logger.info("Error occured while parsing job application status.");
			}
			if(candidateLabel != null && !candidateLabel.isEmpty() && statusLabel != null && !statusLabel.isEmpty() )
			{
				if (revelianPositionId != null && !revelianPositionId.isEmpty())
				{
					String responseForAssessment = client.getDataFromRevelian("/positions"+"/"+revelianPositionId+"/"+"assessments");
					logger.info("Response for assessments assigned to a position ::: "+responseForAssessment);
					listOrgAssessment = getOrgAssesment(responseForAssessment,revelianPositionId);					
					for(String orgAssessment : listOrgAssessment)
					{
						logger.info("Generating invitation id for Organization Assessment : "+orgAssessment);
						if(orgAssessment != null && !orgAssessment.isEmpty())
						{	
							if(revelianCandidateId != null && !revelianCandidateId.isEmpty())
							{
								Invitations invite = (Invitations) createInvitations(revelianCandidateId,orgAssessment,"2050-01-01","REMOTE");
								String responseForInvite = client.postDataToRevelian("/positions"+"/"+revelianPositionId+"/"+"invitations", invite);
								logger.info("Response for fetching invitation id : "+responseForInvite);
								if(!responseForInvite.isEmpty())
								{
									invitationId = SFInvitationJsonParsingUtil.parseInvitationIdResp(responseForInvite);
									logger.info("Fetched invitation id : "+invitationId);
									if(invitationId == null) 
									{
										invitationId = "-1";
									}
								}
								else
								{
									logger.info("Error occured while parsing event revelian response or invitation not created.");
		//							invitationId = "b1401b2c-488e-46eb-944f-593210bf1e7a";
								}
							}
						}
						else
						{
							logger.info("Assessment not associated with position");
						}
					}
				}
			}
			else
			{
				logger.info("Candidate status details are empty");
			}
			logger.info("In sendCandidateInvitation:::: revelianPositionId : "+revelianPositionId+", revelianCandidateId : "+revelianCandidateId+", invitationId : "+invitationId);
			forEmail.setPositionId(revelianPositionId);
			forEmail.setCandidateId(revelianCandidateId);
			forEmail.setInvitationId(invitationId);
		}
		catch (Exception e)
		{
			logger.info(e.getMessage());
		}
		return forEmail;
	}

	
	public String sendInvitationEmail(InvitationEmail forEmail) 
	{
		logger.info(" In sendInvitationEmail method");
		String revelianPositionId = forEmail.getPositionId();
		String revelianCandidateId = forEmail.getCandidateId();
		String invitationId = forEmail.getInvitationId();
		String expiryDate="";
		String candidateLoginUrl="";
		String candidateName="";
		String candidateEmail="";
		String emailStatus="";
		InvitationforPosition positionInviteObj = null;
		CandidateDetailsforInvitation candidateObj = null;
		
		if(invitationId != null && !invitationId.isEmpty())
		{
			logger.info("Obtained invitation Id: " + invitationId+" postion id : "+revelianPositionId);
			String invitation_detailsResponse = client.getDataFromRevelian("/positions"+"/"+revelianPositionId+"/"+"invitations"+"/"+invitationId);
			logger.info("Invitation response for invitation id = "+invitationId+" is ::: "+invitation_detailsResponse);
			if(invitation_detailsResponse != null && !invitation_detailsResponse.isEmpty())
			{
				positionInviteObj = (InvitationforPosition) SFInvitationJsonParsingUtil.parseInvitationDetails(invitation_detailsResponse);
				expiryDate = positionInviteObj.getExpiryDate();
				candidateLoginUrl = positionInviteObj.getCandidateLoginUrl();
				logger.info("Obtained expiryDate : "+expiryDate+" and candidate login url : "+candidateLoginUrl);
			}
			else
			{
				logger.info("Unable to fetch invitation details response!");
			}
			logger.info("Now Fetching candidate details...");
			String candidate_detailsResponse = client.getDataFromRevelian("/positions"+"/"+revelianPositionId+"/"+"candidates"+"/"+revelianCandidateId);
			if(candidate_detailsResponse != null && !candidate_detailsResponse.isEmpty())
			{
				candidateObj = (CandidateDetailsforInvitation) SFInvitationJsonParsingUtil.parseCandidateDetails(candidate_detailsResponse);
				candidateName = candidateObj.getFirstName()+" "+candidateObj.getLastName();
				candidateEmail = candidateObj.getEmail(); 
				logger.info("Obtained candidate full name : "+candidateName);
			}
			else
			{
				logger.info("Unable to fetch candidate details response!");
			}
			
			logger.info("Fetched all details required for email : \n"+"Candidate Name : "+candidateName+"\nCandidate Email : "+candidateEmail+"\nCandidateLoginUrl : "+candidateLoginUrl+"\nExpiry date : "+expiryDate);
			logger.info("Generating email template...");
			emailStatus = SFInvitationJsonParsingUtil.generateAndSendEmail(candidateEmail,"Invitation for Assessments",candidateName,candidateLoginUrl,expiryDate);
			if (emailStatus.equals(SFInvitationConstants.EMAIL_SENT_FAILURE)) 
			{
				logger.error(SFInvitationConstants.EMAIL_SENT_FAILURE);
			}
			
		}
		else
		{
			logger.info("Invitation Id is null");
		}
		return emailStatus;
	}

	/**
	 * This method parses application data for fetch job application status id
	 * @param response
	 * @return
	 * @throws JsonProcessingException
	 * @throws IOException
	 */
	private Map<String, Object> parseCandidateAppStatusIdFromSF(String response) throws JsonProcessingException, IOException 
	{
		logger.info(" In parseCandidateAppStatusIdFromSF ");
		Map<String, Object> map = new HashMap<String, Object>();
		JsonParser jsonParser = new JsonFactory().createJsonParser(response);
		map = SFCandidateJsonParsingUtil.parsingJsonForCandidateAppStatusId(jsonParser, map);
		return map;
	}


	/**
	 * This method parses application data for fetch job application status label
	 * @param response
	 * @return
	 * @throws JsonProcessingException
	 * @throws IOException
	 */
	private Map<String, Object> parseCandidateAppStatusLabelFromSF(String response) throws JsonProcessingException, IOException 
	{
		logger.info(" In parseCandidateAppStatusLabelFromSF ");
		Map<String, Object> map = new HashMap<String, Object>();
		JsonParser jsonParser = new JsonFactory().createJsonParser(response);
		map = SFCandidateJsonParsingUtil.parsingJsonForCandidateAppStatusLabel(jsonParser, map);
		return map;
	}


	/**
	 * Calls Invitations POJO and sets invitation details
	 * @param candidate
	 * @param orgAssessment
	 * @param expiry
	 * @param type
	 * @return
	 */
	public Invitations createInvitations(String candidate, String orgAssessment, String expiry, String type)
	{
		Invitations inviteObj = new Invitations();
		inviteObj.setCandidate(candidate);
		inviteObj.setOrganizationAssessment(orgAssessment);
		inviteObj.setExpiryDate(expiry);
		inviteObj.setType(type);
		return inviteObj;
	}


	/**
	 * Parses candidate data to get Revelian details in a map
	 * @param applicationId
	 * @param map
	 * @return
	 */
	public Map<String,Object> getRevelianDetails(String applicationId, Map<String,Object> map)
	{
		try 
		{
			if(applicationId!=null && !applicationId.isEmpty())
			{
				String applicationresponse = successFactorClient.getDataFromSuccessFactors("JobApplication(" + applicationId + ")");
				if(!applicationresponse.isEmpty() && applicationresponse != null)
				{
					map =candidateService.parseCandidateDataFromSF(applicationresponse);
				}
			}
		} 
		catch (JsonProcessingException e) {
			logger.error(e.getMessage());
			// TODO Auto-generated catch block

		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		}
		return map;
	}


	/**
	 * get data from Revelian to fetch organization Assesment
	 * @param responseForAssessment
	 * @param revelianPositionId
	 * @return
	 */
	public List<String> getOrgAssesment(String responseForAssessment,String revelianPositionId)
	{
		List<String> orgAssessmentList = new ArrayList<String>();
		logger.info("Response and position id for revelian::::\n"+responseForAssessment+" "+revelianPositionId);
		String orgAssessment=null;
		String assessmentId=null;
		JsonNode node=null;
		Iterator<JsonNode> nodeIterator=null;
		try 
		{
			if (!responseForAssessment.isEmpty())
			{
				nodeIterator = SFCandidateJsonParsingUtil.parseOrgAssessmentResp(responseForAssessment);
				while(nodeIterator.hasNext())
				{
					node = nodeIterator.next().get("id");
					assessmentId = node.getTextValue();
					logger.info("Fetched assessment id : "+assessmentId);
					String responseForOrgAssessment = client.getDataFromRevelian("/positions"+"/"+revelianPositionId+"/"+"assessments"+"/"+assessmentId);
					logger.info("Response for Assessment assigned by using Assessment Id ::: "+responseForOrgAssessment);
					if(!responseForOrgAssessment.isEmpty())
					{
						orgAssessment = SFCandidateJsonParsingUtil.parseRevelianOrgAssesmentResp(responseForOrgAssessment);
						logger.info("Fetched orgAssessment : "+orgAssessment+"... Adding it to list...");
						orgAssessmentList.add(orgAssessment);
					}
					else
					{
						logger.info("Response for Organization Assessment is empty.");
					}

				}

			}
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		}
		return orgAssessmentList;
	}
}

