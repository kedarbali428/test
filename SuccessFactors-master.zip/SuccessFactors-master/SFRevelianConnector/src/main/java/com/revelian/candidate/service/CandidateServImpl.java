/**
 * 
 */
package main.java.com.revelian.candidate.service;

import java.io.IOException;
import java.util.HashMap;

import java.util.Map;

import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonFactory;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.JsonProcessingException;

import org.json.simple.parser.JSONParser;


import main.java.com.revelian.candidate.model.Candidate;

import main.java.com.revelian.candidate.util.CandidateXmlParsingUtil;
import main.java.com.revelian.candidate.util.SFCandidateConstants;
import main.java.com.revelian.candidate.util.SFCandidateJsonParsingUtil;
import main.java.com.revelian.client.revelian.RevelianClient;
import main.java.com.revelian.client.successfactor.SOAPClient;
import main.java.com.revelian.client.successfactor.SuccessFactorClient;

import main.java.com.revelian.position.util.SFMapConstants;



/**
 * @author Dipali.Rane
 *
 */
public class CandidateServImpl implements CandidateService
{
	static Logger logger = Logger.getLogger(CandidateServImpl.class);
	RevelianClient client = new RevelianClient();
	SuccessFactorClient successFactorClient = new SuccessFactorClient();
	SOAPClient soapclient = new SOAPClient();
	JSONParser parser = new JSONParser();
	private static final String DEFAULT_CANDIDATE_PHONE_NUMBER = "8888000000";
	private String jobRequisitionResponse; 

	/**
	 * This method returns performs task of Parsing SF event Xml Data, Call
	 * ODATA API to get candidate Details, call createCandidate method to create
	 * candidate on Revelian.
	 * 
	 * @param -
	 *            xml Data obtained from SF events
	 */
	public String parseEventAndGetCandidateFromSF(String xmlMessage) {

		logger.info(" In parseEventAndGetCandidateFromSF method");
		String candidateId = null;
		Map<String, Object> map = null;
		String applicationId = null;
		try {
			String entityId = CandidateXmlParsingUtil.parseCandidateXmlData(xmlMessage);
			String response = "";
			if (entityId != null && !entityId.isEmpty()) 
			{
				logger.info("Got entity Id: " + entityId + " Now fetching its details from SF using Odata Api");
				String sessionId = SOAPClient.callSoapWebService();
				applicationId = SOAPClient.callSoapWebServiceForAssessment(entityId, sessionId);
				logger.info("JobApplicationId : "+applicationId);
				response = successFactorClient.getDataFromSuccessFactors("JobApplication(" + applicationId + ")");
			} 
			else 
			{
				logger.error("Error occured while parsing event xml data or application id not present in xml data.");
				throw new RuntimeException("Error - applicationId not found in xml");
			}
			logger.info((response.isEmpty()) ? "Response is empty!" : "Candidate JSON data obtained from sf successfully");

			if (!response.isEmpty()) 
			{
				map = parseCandidateDataFromSF(response);
				String positionId = (String) map.get(SFMapConstants.REVELIAN_POSITION_ID);
				logger.info("Revelian Position Id = " + positionId);
				if (positionId == null)
				{
					candidateId = null;
				} 
				else 
				{
					candidateId = createCandidateInRevelian(map, applicationId);
				}
			}
			

		} 
		catch (Exception e)
		{
			logger.error("Error occured while pasring SF event data or Getting Candidate detials from SF ODATA API. Error : ",e);
		}

		return candidateId;
	}
	
	/**
	 * This method calls SFJsonParsingUtil class method to parse ODATA API Json
	 * Response to get Candidate and job Requisition Details
	 * 
	 * @param response
	 * @return map containing Candidate details, jobrequisition Id
	 * @throws JsonProcessingException
	 * @throws IOException
	 */
	public Map<String, Object> parseCandidateDataFromSF(String response) throws JsonProcessingException, IOException {

		logger.info(" In parseCandidateDataFromSF Parsing JSON response obtained from ODATA API");
		Map<String, Object> map = new HashMap<String, Object>();
		JsonParser jsonParser = new JsonFactory().createJsonParser(response);

		map = SFCandidateJsonParsingUtil.parseCandidateJsonResponse(jsonParser, map, new Candidate());

		jobRequisitionResponse = successFactorClient.getDataFromSuccessFactors("JobRequisition(" + map.get(SFMapConstants.SF_JOB_REQ_ID) + ")");

		String revelianPositionId = parseRequisitionForPositionId(jobRequisitionResponse);
		if (revelianPositionId == null) 
		{
			logger.info("Revelian Position Id Not Found");
			//map.put(SFMapConstants.REVELIAN_POSITION_ID, revelianPositionId);
			
		} 
		else
		{
			map.put(SFMapConstants.REVELIAN_POSITION_ID, revelianPositionId);
		}
		logger.info("Revelian Position Id:" + revelianPositionId);
		Candidate candidate = ((Candidate) map.get(SFCandidateConstants.CANDIDATE_DETAILS));
		if (candidate.getMobile() == null && candidate.getPhone() != null)
		{
			candidate.setMobile(candidate.getPhone());
		}
		else if (candidate.getMobile() != null && candidate.getPhone() == null)
		{
			candidate.setPhone(candidate.getMobile());
		}
		else 
		{
			candidate.setPhone(DEFAULT_CANDIDATE_PHONE_NUMBER);
			candidate.setMobile(DEFAULT_CANDIDATE_PHONE_NUMBER);
		}
		logger.info("After parsing SF ODATA API candidate detils JSON response obtained candidate pojo is : "
				+ ((Candidate) map.get(SFCandidateConstants.CANDIDATE_DETAILS)).toString());

		logger.info("After parsing SF ODATA API  SFJobRequisitionId : " + ((String) map.get(SFMapConstants.SF_JOB_REQ_ID)));
		logger.info("After parsing SF ODATA API  SFRevelianPositionId : "+ ((String) map.get(SFMapConstants.REVELIAN_POSITION_ID)));
		return map;
	}
	/**
	 * This method calls actual createCandidate revelian POST API to create
	 * candidate on Revelian. It gives revelain candidate Id.
	 * 
	 * @param map
	 *            containing Candidate details
	 * @throws IOException
	 * @throws JsonProcessingException
	 */
	@Override
	public String createCandidateInRevelian(Map<String, Object> map, String applicationId) {
			 
		String revelianCandidateId = "";
		
		try
		{
			logger.info("In createCandidateInRevelian, getting position Id from Requisition Id and call createCandidate of Revelian");
			String sfJobReqId = (String) map.get(SFMapConstants.SF_JOB_REQ_ID);
			String sfRevelianPositionId = (String) map.get(SFMapConstants.REVELIAN_POSITION_ID);
			Candidate candidate = (Candidate) map.get(SFCandidateConstants.CANDIDATE_DETAILS);
			logger.info("For requisition Id: " + sfJobReqId + "corresponding position Id is: " + sfRevelianPositionId);
			String response = client.postDataToRevelian("positions" + "/" + sfRevelianPositionId + "/" + "candidates",candidate);
			logger.info((response.isEmpty()) ? "Response is empty!" : "Candidate created successfully!");
			if (response.isEmpty()) 
			{
				logger.info("Candidate Not Create in Revelian.");
				revelianCandidateId = "-1";
			}
			else 
			{
				revelianCandidateId = SFCandidateJsonParsingUtil.parseRevelianCandidateResp(response);
				logger.info("Before Update RevelianCandidateId, ApplicationId=" + applicationId+" and RevelianCandidateId = "+revelianCandidateId);
				 //Check For Country 
				logger.info("Country="+map.get(SFCandidateConstants.CANDIDATECOUNTRY));
				String country = (String) map.get(SFCandidateConstants.CANDIDATECOUNTRY);
				successFactorClient.sendDataToSF(applicationId, "country", country,"JobApplication");
				//update field to candidateId to sucessfactor 
				successFactorClient.sendDataToSF(applicationId, "Revelian_Candidate_Id", revelianCandidateId,"JobApplication");
				logger.info("After Update Revelian Id to SF= " + revelianCandidateId);
			}
      }
      catch(JsonProcessingException e)
      {
    	  logger.info("Error Occuring JSON Parsing");
    	  logger.error(e.getMessage());
      }
      catch(IOException e)
      {
    	  logger.info("Error Occuring JSON Parsing");
    	  logger.error(e.getMessage());
      }
		return revelianCandidateId;
	}
	
	/**
	 * This method uses all the parsed Json Data obtained in map find Revelian
	 * ID.
	 * 
	 * @param map
	 * @param position
	 */

	private String parseRequisitionForPositionId(String jobRequisitionResponse) throws JsonParseException, IOException {
		logger.info(" In parseRequisitionJsonDatafromSF Parsing JSON response obtained from ODATA API");

		Map<String, String> map = new HashMap<String, String>();
		JsonParser jsonParser = new JsonFactory().createJsonParser(jobRequisitionResponse);
		map = SFCandidateJsonParsingUtil.parseRequistionForPosition(jsonParser, map);
		logger.info("After parsing SF ODATA API Job Requisition Locale data obtained is: "
				+ map.get(SFMapConstants.REVELIAN_POSITION_ID));
		String revelianPositionId = map.get(SFMapConstants.REVELIAN_POSITION_ID);
		logger.info("Revelian Position Id=" + revelianPositionId);
		return revelianPositionId;

	}

	
	
	
}
