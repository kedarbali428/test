package main.java.com.revelian.score.service;

import java.util.Map;

public interface ScoreService {
	public String updateCandidateScoreToRevelian(String positionId,String candidateId);
	public String updateScoreToSucessFactor(String  applicationId,Map<String, String> result);
}
