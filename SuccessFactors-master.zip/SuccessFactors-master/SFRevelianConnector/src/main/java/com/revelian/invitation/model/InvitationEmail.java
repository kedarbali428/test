package main.java.com.revelian.invitation.model;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Sayali.Parkhi
 *
 */
@XmlRootElement
public class InvitationEmail 
{
	private String positionId;
	private String candidateId;
	private String invitationId;
	
	
	public String getPositionId() {
		return positionId;
	}
	public void setPositionId(String positionId) {
		this.positionId = positionId;
	}
	public String getCandidateId() {
		return candidateId;
	}
	public void setCandidateId(String candidateId) {
		this.candidateId = candidateId;
	}
	public String getInvitationId() {
		return invitationId;
	}
	public void setInvitationId(String invitationId) {
		this.invitationId = invitationId;
	}
	
	
	
}
