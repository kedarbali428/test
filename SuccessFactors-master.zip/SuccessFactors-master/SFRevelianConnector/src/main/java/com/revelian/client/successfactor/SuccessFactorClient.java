package main.java.com.revelian.client.successfactor;

import java.net.URI;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriBuilder;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

import main.java.com.revelian.errorstatus.model.ErrorStatus;
import main.java.com.revelian.errorstatus.util.ErrorParsing;
import main.java.com.revelian.sfauthdetail.SFAuthDetailServlet;
import sun.misc.BASE64Encoder;


/**
 * This class used to call OData API's of SF
 * Send or get data to or from SF
 * @author Dipali.Rane
 *
 */

public class SuccessFactorClient 
{
	static Logger logger = Logger.getLogger(SuccessFactorClient.class);
	static String sfUserName="";
	static String sfId="";
	static String sfCompanyLink="";
	static String authString="";
	Client client ;
	WebResource webResource ;
	JSONObject jsonObjectMetadata=null;
	Object object=null;
	String EMPTY = "";
	static String password="";
	
	SFAuthDetailServlet sfAuthDetailServlet=new SFAuthDetailServlet();
	String companyId = sfAuthDetailServlet.getCompanyId();
	
	
	
	
	/**
	 * This mathod id used to send data to sucessfactor 
	 * @param applicationId
	 * @param fieldToUpdate
	 * @param value
	 * @param entityToUpdate
	 * @return
	 */
	public String sendDataToSF(String applicationId,String fieldToUpdate,String value,String entityToUpdate)
	{ 
		
		logger.info(applicationId+" and update to"+ value);
		String output="";
		String authString = new ConfigDetails().returnAuthString();
		String authStringEnc = new BASE64Encoder().encode(authString.getBytes());
		try 
		{
		 	String metadataUrl=entityToUpdate+"("+applicationId+"L)";
		    jsonObjectMetadata=getMetaDataFromSF(metadataUrl);
			JSONObject jsonObject =  new JSONObject() ;
			jsonObject.put("__metadata",jsonObjectMetadata);
			jsonObject.put(fieldToUpdate,value);
		 	logger.info("Json Object: "+jsonObject);
		 	String urlParam="upsert";
			WebResource webResource = getWebResourseObjectToGivenUrl(urlParam);
			ObjectMapper mapper = new ObjectMapper();
			ClientResponse resp = webResource.accept("application/json")
			.header("Authorization", "Basic " + authStringEnc).header("Content-type", "application/json")
			.post(ClientResponse.class, mapper.writeValueAsString(jsonObject)); 
			
			logger.info("CLientResponse : "+resp);
			if(resp.getStatus() != 200)
			{
				logger.info("Unable to connect to the server");
			}
			 output = resp.getEntity(String.class);
			logger.info("Post request response from SF: "+output); 	
	   }
	   catch (Exception e)
	   {
	       	logger.error(e.getMessage());
	   }
		return output;
	}
	
	/**
	 * This method returns the Metadata 
	 * Metadata is used as unique key while posting data to SF
	 * @param url
	 * @return
	 */
	public JSONObject getMetaDataFromSF(String url)
	{
	   try 
	   {
	  	String output;
	  	String authString = new ConfigDetails().returnAuthString();
		String authStringEnc = new BASE64Encoder().encode(authString.getBytes());
		webResource = getWebResourseObjectToGivenUrl(url);
		ClientResponse resp = (ClientResponse) webResource.accept(MediaType.APPLICATION_JSON_TYPE) .header("Authorization", "Basic " + authStringEnc).get(ClientResponse.class);
		logger.info("CLientResponse"+resp);
		if(resp.getStatus() != 200)
		{
			
			logger.info("Unable to connect to the server");
		}
		
		logger.info("Wait For Responce");
		output = resp.getEntity(String.class);
		
		JSONParser parser = new JSONParser();
		JSONObject json = (JSONObject) parser.parse(output);
		
		object = json.get("d");
		JSONObject parentJsonObject = (JSONObject) object;
		object = parentJsonObject.get("__metadata");
		jsonObjectMetadata = (JSONObject) object;	
	   } 
	   catch (ParseException e)
	   {
        logger.error(e.getMessage());
	   }
		  
	   logger.info("metadata :"+jsonObjectMetadata);
	   return jsonObjectMetadata;
	}
	
	/**
	 * This Method genrates baseURI
	 * @return
	 */
	private static URI getBaseURI()
	{
		
		sfCompanyLink = new ConfigDetails().getSfCompanyLink();
		String odata="/odata/";
		String version="v2/";
		String companyuri = sfCompanyLink + odata + version;
	   return UriBuilder.fromUri(companyuri).build();
	}
	
	/**
	 * Get Webresource
	 * @param url
	 * @return
	 */
	public WebResource getWebResourseObjectToGivenUrl(String url)
	{
	   try
	   {
		client = Client.create();
		webResource = client.resource(getBaseURI()).path(url);
	   }
	   catch(Exception e)
	   {
		logger.error(e.getMessage());
	   }
	   return webResource;
	}
	
/**
 *This is generic method to GET data from Success Factors ODATA API.
 * 
 * @param URL
 */
public String getDataFromSuccessFactors(String url)
{
	String output=null;
	String sfurl=getBaseURI()+url;
	
	try
	{
		String authString = new ConfigDetails().returnAuthString();
		String authStringEnc = new BASE64Encoder().encode(authString.getBytes());
				
		
		Client restClient = Client.create();
		WebResource webResource = restClient.resource(sfurl);
		ClientResponse resp = (ClientResponse) webResource.accept(MediaType.APPLICATION_JSON_TYPE) .header("Authorization", "Basic " + authStringEnc).get(ClientResponse.class);
		if(resp.getStatus() != 200){
		    logger.error("Unable to connect to the server");
		}
		
		 output = resp.getEntity(String.class);
		logger.info("response: "+output);
	} catch (Exception e) {
				logger.error("Error occurred: " + e);
	}
	return output;
}
	

	
	
}

