package main.java.com.revelian.position.util;


import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

/**
 * This class is mainly concerned with Parsing xml data obtained from SF events.
 * 
 * @author Dipali.Rane
 *
 */
public class XmlParsingUtil {

	static Logger logger = Logger.getLogger(XmlParsingUtil.class);
	static String JOB_REQUISITION_ID_STRING = "jobReqId";
	static String EVENT_TAG = "event";
	static String PARAM_TAG = "param";
	static String ENTITY_KEY_TAG = "entityKey";
	static String NAME_TAG = "name";
	static String VALUE_TAG = "value";
	static String SOAP_BODY_TAG = "S:Body";
	static String EXTERNAL_EVENT = "ExternalEvent";

	/**
	 * This Method parse JobRequisition data From SucessFactor
	 * @param xmlData
	 * @return jobReqId
	 */
	public static String parseJobRequisitionXmlData(String xmlData) {

		String jobRequisitionId = null;

		try {
			logger.info("In parseJobRequisitionXmlData");

			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(new InputSource(new StringReader(xmlData)));
			doc.getDocumentElement().normalize();

			Element rootElement = doc.getDocumentElement();
			logger.info("Root element :" + rootElement.getNodeName());
			NodeList soapBodyList = doc.getElementsByTagName(SOAP_BODY_TAG);
			logger.info("Soap body elements list size : " + soapBodyList.getLength());
			NodeList bodyChildList = soapBodyList.item(0).getChildNodes();
			String extractPrefix = "";

			for (int i = 0; i < bodyChildList.getLength(); i++) 
			{
				Node nNode = bodyChildList.item(i);

				if (nNode.getNodeType() == Node.ELEMENT_NODE && nNode.getNodeName().contains(EXTERNAL_EVENT)) {
					extractPrefix = nNode.getNodeName().split(":")[0];
					extractPrefix = extractPrefix + ":";
					
					logger.info("Prefix obtained is:" + extractPrefix);
					break;
				}
			}

			NodeList nList = doc.getElementsByTagName(extractPrefix + EVENT_TAG);
			Node nNode = nList.item(0);
			NodeList list = ((Element) nNode).getElementsByTagName(extractPrefix + ENTITY_KEY_TAG);

			for (int i = 0; i < list.getLength(); i++)
			{
				Node node = list.item(i);

				if (node.getNodeType() == Node.ELEMENT_NODE	&& node.getNodeName().equals(extractPrefix + ENTITY_KEY_TAG)) 
				{
					NodeList childList = ((Element) node).getElementsByTagName(NAME_TAG);
				
					if (childList.item(0).getTextContent().equals(JOB_REQUISITION_ID_STRING)) 
					{
						childList = ((Element) node).getElementsByTagName(VALUE_TAG);
						jobRequisitionId = childList.item(0).getTextContent();
						logger.info("Job Requisition Id fetched from xml parsing: " + jobRequisitionId);
					}
				}
			}

		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return jobRequisitionId;
	}

}
