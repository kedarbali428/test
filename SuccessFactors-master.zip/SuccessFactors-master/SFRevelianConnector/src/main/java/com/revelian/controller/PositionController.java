package main.java.com.revelian.controller;

import java.io.IOException;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import org.apache.log4j.Logger;
import main.java.com.revelian.candidate.service.CandidateServImpl;
import main.java.com.revelian.invitation.model.InvitationEmail;
import main.java.com.revelian.invitation.service.InvitationsServImpl;
import main.java.com.revelian.position.service.PositionServImpl;
import main.java.com.revelian.score.service.ScoreServiceImpl;

/**
 * This class manage position and candidates
 * 
 * @author Dipali.Rane
 *
 */

@Path("/position")
public class PositionController {

	static Logger logger = Logger.getLogger(PositionController.class);
	private String param = "";
	private String xmlResponse = null;

	private PositionServImpl posService = new PositionServImpl();
	private CandidateServImpl candidateService = new CandidateServImpl();
	private ScoreServiceImpl scoreService = new ScoreServiceImpl();
	private InvitationsServImpl invitationService = new InvitationsServImpl();
	/**
	 * Test controller method
	 */
	
	  @GET
	  
	  @Produces(MediaType.APPLICATION_XML) public String getPosition() throws
	  IOException {
	  
	 
	 
	 logger.debug("this is a debug log message");
	 logger.info("this is a information log message");
	 logger.warn("this is a warning log message"); return "HELLO"; }
	
	/**
	 * This method create the position to Revelian
	 * @param message
	 * @return
	 * @throws IOException
	 */
	@POST
	public Response createPositionInRevelian(String message, @Context UriInfo uriInfo) throws IOException {
		Response response=null;
		logger.info("In createPositionInRevelian:: " + message);
		String positionUrl = uriInfo.getAbsolutePath().toString();
		String sfUrl = "salesdemo4.successfactors.com";
		String endpointUrl = positionUrl+"?uri="+sfUrl;
		logger.info("endpointUrl ::::::: "+endpointUrl);
		String positionId = posService.createPositionInRevelian(message);
       
		if (positionId != null && !positionId.equals("")) 
		{
			if (positionId.equals("-1")) 
			{
				xmlResponse = getXML("400", "position already Created!");
				
				response = Response.status(Response.Status.OK).header("Content-Type", "text/xml")
						.header("Accept", "text/xml").entity(xmlResponse).build();
				logger.info((String)response.getEntity());
				
			}
			else if (positionId.equals("0")) 
			{
				xmlResponse = getXML("400", "Position not created,As required fields can not be empty !");
				
				response = Response.status(Response.Status.OK).header("Content-Type", "text/xml")
						.header("Accept", "text/xml").entity(xmlResponse).build();
				logger.info((String)response.getEntity());
				
			} 
			else 
			{
				xmlResponse = getXML("201", "position created successfully, positionId= " + positionId);
				 response = Response.status(Response.Status.OK).header("Content-Type", "text/xml")
							.header("Accept", "text/xml").entity(xmlResponse).build();
				 logger.info((String)response.getEntity());

			}
		}

	
		return response;
	}

	/**
	 * This Method Create Candidate  candidate on Revelian
	 * @param data
	 * @return
	 */
	@POST
	@Path("/createcandidate")
	public Response createCandidateInRevelian(String data) {

		logger.info("In createCandidate:: " + data);
		Response response =null;
		String candidateId =candidateService.parseEventAndGetCandidateFromSF(data);
		String emailStatus = sendInvitationToCandidate(candidateId) ;
		
		if (candidateId != null && !candidateId.equals("")) 
		{
			
			if (candidateId.equals("-1")) 
			{
				
				xmlResponse = getXMLforCandidate("400", "Candidate Not Created");
				response = Response.status(Response.Status.OK).header("Content-Type", "text/xml")
						.header("Accept", "text/xml").entity(xmlResponse).build();
			}
			else
			{
				if(emailStatus != null && !emailStatus.isEmpty())
				{
					xmlResponse = getXMLforCandidate("201", "Candidate Created Id= " + candidateId+" and "+emailStatus);
					response= Response.status(Response.Status.OK).header("Content-Type", "text/xml")
						.header("Accept", "text/xml").entity(xmlResponse).build();
				}
				
			}
		}
		
		
		return response;

	}

	/**
	 * Send Invitation To Candidate
	 * @param data
	 * @return
	 */
	@POST
	@Path("/sendInvitation")
	public String sendInvitationToCandidate(String data) 
	{
		logger.info("In sendInvitation:: " + data);
		Response response =null;
		String status = "";
		InvitationEmail emailObj = (InvitationEmail) invitationService.sendCandidateInvitation(data);
		String invitationId = emailObj.getInvitationId();
		if (invitationId != null && !invitationId.equals(""))
		{
			if (invitationId.equals("-1")) 
			{
				xmlResponse = getXMLforInvitation("400", "Candidate Not Created");
				response = Response.status(Response.Status.OK).header("Content-Type", "text/xml")
						.header("Accept", "text/xml").entity(xmlResponse).build();
			}
			else
			{
				xmlResponse = getXMLforInvitation("201", "Candidate Created Id= " + invitationId);
				response= Response.status(Response.Status.OK).header("Content-Type", "text/xml")
					.header("Accept", "text/xml").entity(xmlResponse).build();
			
				status = invitationService.sendInvitationEmail(emailObj);
			}
		}
		else
		{
			xmlResponse = getXMLforInvitation("400", "Candidate has already been invited to assessment");
			response= Response.status(Response.Status.OK).header("Content-Type", "text/xml")
					.header("Accept", "text/xml").entity(xmlResponse).build();
		}
		return status;
	}

	
	
	/**
	 * This method calls the Revelian API to get score of candidate
	 *
	 * @return
	 */
	@GET
	@Path("/score/{positionId}/{candidateId}")
	
	public String ScoreFromRevelian(@PathParam("positionId") String positionId,@PathParam("candidateId") String candidateId) 
	{
		logger.info("positionid=" + positionId);
		logger.info("candidateid=" + candidateId);
		String result=scoreService.updateCandidateScoreToRevelian(positionId,candidateId);
		return result;
	}

	private String getXML(String code, String message) 
	{
		String response = "<?xml version=\'1.0\' encoding=\'UTF-8\'?><S:Envelope xmlns:S=\"http://schemas.xmlsoap.org/soap/envelope/\">"
				+ "<S:Body><responsePayload><status>" + code + "</status><statusDetails> " + message
				+ "</statusDetails></responsePayload></S:Body></S:Envelope>";
		return response;
	}

	private String getXMLforCandidate(String code, String message) 
	{
		String response = "<?xml version=\'1.0\' encoding=\'UTF-8\'?><S:Envelope xmlns:S=\"http://schemas.xmlsoap.org/soap/envelope/\">"
				+ "<S:Body><createRcmAssessmentRequestResponse xmlns=" + ""+"'" + "http://alert.successfactors.com"+"'"+">"
				+ "<rcmAssessmentResponse><assessmentUrl>"+"https://www.cebglobal.com/shldirect/en-us/practice-tests"+"</assessmentUrl>"
				+ "<receiptId>5144901</receiptId>" + "<status>"+code+"</status>" + "<statusDetails>"
				+ message + "</statusDetails>" + "</rcmAssessmentResponse></createRcmAssessmentRequestResponse>"
				+ "</S:Body>" + "</S:Envelope>";
		return response;
	}
	
	private String getXMLforInvitation(String code, String message) 
	{
		String response = "<?xml version=\'1.0\' encoding=\'UTF-8\'?><S:Envelope xmlns:S=\"http://schemas.xmlsoap.org/soap/envelope/\">"
				+ "<S:Body><createRcmAssessmentRequestResponse xmlns=" + "'" + "http://alert.successfactors.com'"+">"
				+ "<rcmAssessmentResponse><assessmentUrl>"+"https://www.cebglobal.com/shldirect/en-us/practice-tests"+"</assessmentUrl>"
				+ "<receiptId>5144901</receiptId>" + "<status>"+code+"</status>" + "<statusDetails>"
				+ message + "</statusDetails>" + "</rcmAssessmentResponse></createRcmAssessmentRequestResponse>"
				+ "</S:Body>" + "</S:Envelope>";
		return response;
	}
}
