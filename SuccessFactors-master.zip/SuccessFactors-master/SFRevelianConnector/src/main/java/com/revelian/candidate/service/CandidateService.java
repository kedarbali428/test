package main.java.com.revelian.candidate.service;

import java.util.Map;

public interface CandidateService 
{
	public String parseEventAndGetCandidateFromSF(String xmlMessage);
	String createCandidateInRevelian(Map<String, Object> map, String applicationId);
}
