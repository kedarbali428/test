package main.java.com.revelian.client.successfactor;


import java.util.ArrayList;
import java.util.List;

import javax.xml.soap.*;

import org.apache.log4j.Logger;


import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * This is SOAP Client for SucessFactor Candidate Response
 * @author Dipali.Rane
 *
 */
public class SOAPClient 
{
	static Logger logger = Logger.getLogger(SOAPClient.class);
	static String sfUserName="";
	static String sfCompanyId="";
	static String sfPassword="";
	static String sfCompanyLink="";
	static String endpointUrl="";
	static final String SFAPI="/sfapi/";
	static String VERSION="v1";
	static final String SOAP="/soap?wsdl";
	static ConfigDetails conf=new ConfigDetails();


	private static SOAPMessage createSoapEnvelope(SOAPMessage soapMessage) throws SOAPException {
		try {


			sfUserName=conf.getSfUserName();
			sfPassword=conf.getPassword();
			sfCompanyId=conf.getSfId();

			SOAPPart soapPart = soapMessage.getSOAPPart();

			String urn = "urn";
			String myNamespaceURI = "urn:sfobject.sfapi.successfactors.com";

			// SOAP Envelope
			SOAPEnvelope envelope = soapPart.getEnvelope();
			envelope.addNamespaceDeclaration(urn, myNamespaceURI);
			//SoapBody
			SOAPBody soapBody = envelope.getBody();
			SOAPElement soapBodyElem = soapBody.addChildElement("login", "urn");
			SOAPElement soapBodyElem1 = soapBodyElem.addChildElement("credential", "urn");
			SOAPElement soapBodyElem2 = soapBodyElem1.addChildElement("companyId", "urn");
			soapBodyElem2.addTextNode(sfCompanyId);
			SOAPElement soapBodyElem3 = soapBodyElem1.addChildElement("username", "urn");
			soapBodyElem3.addTextNode(sfUserName);
			SOAPElement soapBodyElem4 = soapBodyElem1.addChildElement("password", "urn");
			soapBodyElem4.addTextNode(sfPassword);
		
		} 
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			logger.error("On SoapClient="+e.getMessage());
		}
		logger.info("In createSoapEnvelope , soapmsg : "+soapMessage.toString());
		return soapMessage;
	}

	
	/**
	 * Soap Webservice Login
	 * @return
	 */
	public static String  callSoapWebService()
	{
		sfCompanyLink=conf.getSfCompanyLink();
		endpointUrl=sfCompanyLink+SFAPI+VERSION+SOAP;
		logger.info("Endpoint URL::"+endpointUrl);
		SOAPMessage soapResponse = null;
		String sessionId=null;
		try 
		{
			// Create SOAP Connection
			SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
			SOAPConnection soapConnection = soapConnectionFactory.createConnection();

			// Send SOAP Message to SOAP Server
			soapResponse = soapConnection.call(createSOAPRequest(), endpointUrl);

			Node respBody = (Node) soapResponse.getSOAPBody().getFirstChild();
			Node loginResp = (Node) respBody.getFirstChild();
			NodeList nodeList =  loginResp.getChildNodes();
			List<String> ids = new ArrayList<String>(nodeList.getLength());
			for(int i=0;i<nodeList.getLength(); i++)
			{
				Node x = (Node) nodeList.item(i);
				ids.add(x.getFirstChild().getNodeValue());
				sessionId=nodeList.item(0).getFirstChild().getNodeValue();
			}
			soapConnection.close();
		} catch (Exception e) {
			logger.info("\nError occurred while sending SOAP Request to Server!\nMake sure you have the correct endpoint URL and SOAPAction!\n");
			logger.error(e.getMessage());
		}
		return sessionId;
	}

	private static SOAPMessage createSOAPRequest() throws Exception {
		MessageFactory messageFactory = MessageFactory.newInstance();
		SOAPMessage soapMessage = messageFactory.createMessage();
		soapMessage = createSoapEnvelope(soapMessage);
		logger.info("in createSOAPRequest soap msg : "+soapMessage.toString());
		return soapMessage;
	}
	///For Assessment

	/**
	 * This Method create  for queryString  For Assessment
	 * @param entityId
	 * @param SessionId
	 * @return
	 */
	public static String  callSoapWebServiceForAssessment(String entityId,String SessionId) {
		sfCompanyLink=conf.getSfCompanyLink();
		endpointUrl=sfCompanyLink+SFAPI+VERSION+SOAP;
		logger.info("Endpoint URL:: "+endpointUrl);
		SOAPMessage soapResponse = null;
		String applicationId=null;
		try 
		{
			// Create SOAP Connection
			SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
			SOAPConnection soapConnection = soapConnectionFactory.createConnection();
			// Send SOAP Message to SOAP Server
			soapResponse = soapConnection.call(createSOAPRequestForAssessment(SessionId,entityId), endpointUrl);
			Node queryResponse = (Node) soapResponse.getSOAPBody().getFirstChild();
			Node result = (Node) queryResponse.getFirstChild();
			Node sfobject = (Node) result.getFirstChild();
			NodeList object = (NodeList) sfobject.getChildNodes();

			for(int i=0;i<object.getLength(); i++) {
				Node x = (Node) object.item(i);
				if("applicationId".equals(x.getNodeName())) 
				{
					applicationId= x.getTextContent();
				}
			}
			soapConnection.close();
		} catch (Exception e) {
			logger.info("\nError occurred while sending SOAP Request to Server!\nMake sure you have the correct endpoint URL and SOAPAction!\n");
			logger.error(e.getMessage());
		}
		return applicationId;
	}

	/**
	 * Create SoapMessage
	 * @param sessionId
	 * @param entityId
	 * @return
	 */
	private static SOAPMessage createSOAPRequestForAssessment(String sessionId,String entityId)  {
		SOAPMessage soapMessage = null;
		try
		{
			MessageFactory messageFactory = MessageFactory.newInstance();
			soapMessage = messageFactory.createMessage();
			soapMessage = createSoapEnvelopeForAssessment(soapMessage,entityId);
			logger.info("Soap msg in createSOAPRequestForAssessment:  "+soapMessage.toString());
			MimeHeaders headers = soapMessage.getMimeHeaders();
			
			headers.addHeader("Cookie", "JSESSIONID="+sessionId);

			soapMessage.saveChanges();

			
		}
		catch(Exception e)
		{
			logger.info(e.getMessage());
		}
		return soapMessage;
	}
	/**
	 * Create Saop Envelope
	 * @param soapMessage
	 * @param entityId
	 * @throws SOAPException
	 */
	private static SOAPMessage createSoapEnvelopeForAssessment(SOAPMessage soapMessage,String entityId) throws SOAPException {   

		SOAPElement soapElm = null;
		try
		{
			SOAPPart soapPart = soapMessage.getSOAPPart();

			String urn = "urn";
			String myNamespaceURI = "urn:sfobject.sfapi.successfactors.com";

			// SOAP Envelope
			SOAPEnvelope envelope = soapPart.getEnvelope();
			envelope.addNamespaceDeclaration(urn, myNamespaceURI);

			// SOAP Body

			SOAPBody soapBody = envelope.getBody();
			SOAPElement soapBodyElem = soapBody.addChildElement("query", "urn");
			SOAPElement soapBodyElem1 = soapBodyElem.addChildElement("queryString", "urn");
			soapElm = soapBodyElem1.addTextNode("select partnerId, clientId, jobReqId, candidateId, vendorCode, assessmentPackageCode, applicationId from AssessmentOrder where id="+entityId+"");
			logger.info("soap element : "+soapElm.toString());
//			soapMessage = (SOAPMessage) soapElm;
			logger.info("soap message : "+soapMessage.toString());
		}
		catch(SOAPException e)
		{
			logger.info(e.getMessage());
		}
		return soapMessage;
	}



}