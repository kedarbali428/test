package main.java.com.revelian.position.model;

public class Contacts {

	Contact contact;
	Supervisor supervisor;

	public Contacts() {
	}

	public Contacts(Contact contact, Supervisor supervisor) {

		this.contact = contact;
		this.supervisor = supervisor;
	}

	public Contact getContact() {
		return contact;
	}

	public void setContact(Contact contact) {
		this.contact = contact;
	}

	public Supervisor getSupervisor() {
		return supervisor;
	}

	public void setSupervisor(Supervisor supervisor) {
		this.supervisor = supervisor;
	}

	@Override
	public String toString() {
		return "Contacts [contact=" + contact + ", supervisor=" + supervisor + "]";
	}

}
