package main.java.com.revelian.position.service;

import main.java.com.revelian.position.model.Position;

/**
 * This is interface for create position and update Candidate score
 * 
 * @author Dipali.Rane
 *
 */
public interface PositionService 
{

	public String createPosition(Position position);
	public String createPositionInRevelian(String xmlMessage);
	

}
