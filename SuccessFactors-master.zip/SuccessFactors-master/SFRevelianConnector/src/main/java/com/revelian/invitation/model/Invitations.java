package main.java.com.revelian.invitation.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Invitations
{
	private String candidate;
	private String organizationAssessment;
	private String expiryDate;
	private String type;
	
	
	public String getCandidate() {
		return candidate;
	}
	public void setCandidate(String candidate) {
		this.candidate = candidate;
	}
	public String getOrganizationAssessment() {
		return organizationAssessment;
	}
	public void setOrganizationAssessment(String organizationAssessment) {
		this.organizationAssessment = organizationAssessment;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	
	
}
