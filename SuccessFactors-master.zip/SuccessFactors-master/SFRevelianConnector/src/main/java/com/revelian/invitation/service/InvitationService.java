package main.java.com.revelian.invitation.service;


import main.java.com.revelian.invitation.model.InvitationEmail;
import main.java.com.revelian.invitation.model.Invitations;

/**
 * This Class for Invitation Service(Send Invitation To candidate)
 * @author Dipali.Rane
 *
 */
public interface InvitationService
{
	public Invitations createInvitations(String candidate, String orgAssessment, String expiry, String type);
	public Object sendCandidateInvitation(String xmlMessage);
	public String sendInvitationEmail(InvitationEmail forEmail);
}
