package main.java.com.revelian.client.successfactor;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * This class reads config.xml file and gets config details
 * 
 * @author Sayali.Parkhi
 *
 */

public class ConfigDetails
{
	String sfUserName="";
	String sfId="";
	String sfCompanyLink="";
	String authString="";
	String password="";
	Logger logger = Logger.getLogger(ConfigDetails.class);
	NodeList nList=null;
   
	
		
	
	public NodeList readConfigFile()
	{
		try 
		{
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.newDocument();
			String rootPath =System.getProperty("catalina.home");
			File file = new File(rootPath+"/conf","SFConnector_config.xml");
			doc = dBuilder.parse(file);
			doc.getDocumentElement().normalize();
			nList = doc.getElementsByTagName("User");
		}
		catch (Exception e) 
		{
			logger.error(e.getMessage());
		}
		return nList;
	}
	public Properties readPropertiesFileDetails(String filename)
	{
		Properties properties = null;
		try {
			String rootPath =System.getProperty("catalina.home");
			FileInputStream fileInput = new FileInputStream(rootPath+"/conf/"+filename);
			properties = new Properties();
			properties.load(fileInput);
			fileInput.close();
		} catch (FileNotFoundException e) {
			logger.error(e.getMessage());
		} catch (IOException e) {
			logger.error(e.getMessage());
		}
		return properties;
		
	}
	
	
    public String getSfUserName()
    {
    	nList = readConfigFile();
    	for (int i = 0; i < nList.getLength(); i++)
		{
			Node nNode = nList.item(i);
			Element eElement = (Element) nNode;
			sfUserName = (eElement.getElementsByTagName("User_Name").item(0)).getTextContent();
			
		}
		return sfUserName;
	}
    
	
    public String getSfId() 
	{
		nList = readConfigFile();
    	for (int i = 0; i < nList.getLength(); i++)
		{
			Node nNode = nList.item(i);
			Element eElement = (Element) nNode;
			sfId = (eElement.getElementsByTagName("Company_Id").item(0)).getTextContent();
		}
		return sfId;
	}
	

	public String getSfCompanyLink() 
	{
		nList = readConfigFile();
    	for (int i = 0; i < nList.getLength(); i++)
		{
			Node nNode = nList.item(i);
			Element eElement = (Element) nNode;
			sfCompanyLink = (eElement.getElementsByTagName("CompanyLink").item(0)).getTextContent();
		}
		return sfCompanyLink;
	}
	
	
	public String getPassword() 
	{
		nList = readConfigFile();
    	for (int i = 0; i < nList.getLength(); i++)
		{
			Node nNode = nList.item(i);
			Element eElement = (Element) nNode;
			password=(eElement.getElementsByTagName("Password").item(0)).getTextContent();
		}
		return password;
	}
	
	public String returnAuthString()
	{
		authString = getSfUserName() +"@"+ getSfId() + ":" + getPassword();
		//authString = getSfUserName() + ":" + getPassword();
		return authString;
	}
	
}
