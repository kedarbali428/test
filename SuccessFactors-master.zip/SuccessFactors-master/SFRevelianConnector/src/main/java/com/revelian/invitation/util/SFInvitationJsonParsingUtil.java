package main.java.com.revelian.invitation.util;

import java.io.IOException;
import java.io.StringWriter;
import java.security.Security;

import java.util.Iterator;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import org.apache.log4j.Logger;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.exception.ParseErrorException;
import org.apache.velocity.exception.ResourceNotFoundException;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.JsonProcessingException;

import org.codehaus.jackson.map.ObjectMapper;


import main.java.com.revelian.candidate.util.SFCandidateJsonParsingUtil;

import main.java.com.revelian.client.successfactor.ConfigDetails;
import main.java.com.revelian.invitation.model.CandidateDetailsforInvitation;
import main.java.com.revelian.invitation.model.InvitationforPosition;

/**
 * @author Sayali.Parkhi
 *
 */
public class SFInvitationJsonParsingUtil 
{
	
	static Logger logger = Logger.getLogger(SFCandidateJsonParsingUtil.class);
	
	
	public static String parseInvitationIdResp(String response)throws JsonProcessingException, IOException
	{
		JsonNode actualObj = new ObjectMapper().readTree(response);
		JsonNode positionIdNode = actualObj.get("id");
		String invitationId = positionIdNode.getTextValue();
		logger.info("Revelian invitation id: " + invitationId);
		return invitationId;
	}
	
	public static Object parseInvitationDetails(String invitation_detailsResponse)
	{
		logger.info("Inside parseInvitationDetails method.");
		InvitationforPosition objInvite = new InvitationforPosition();
		try 
		{
			ObjectMapper mapper = new ObjectMapper();
			JsonNode root = mapper.readTree(invitation_detailsResponse);
			Iterator<String> fieldnames = root.getFieldNames();
			
			while (fieldnames.hasNext())
			{
				String fieldname = fieldnames.next();
				if("id".equals(fieldname))
				{
					objInvite.setInvitationId(root.get(fieldname).getTextValue());
				}
				if("candidate".equals(fieldname))
				{
					objInvite.setCandidateId(root.get(fieldname).getTextValue());
				}
				if("organizationAssessment".equals(fieldname))
				{
					objInvite.setOrgAssessment(root.get(fieldname).getTextValue());
				}
				if("expiryDate".equals(fieldname))
				{
					objInvite.setExpiryDate(root.get(fieldname).getTextValue());
				}
				if("type".equals(fieldname))
				{
					objInvite.setType(root.get(fieldname).getTextValue());
				}
				if("status".equals(fieldname))
				{
					objInvite.setStatus(root.get(fieldname).getTextValue());
				}
				if("candidateLoginUrl".equals(fieldname))
				{
					objInvite.setCandidateLoginUrl(root.get(fieldname).getTextValue());
				}
				if("created".equals(fieldname))
				{
					objInvite.setCreated(root.get(fieldname).getTextValue());
				}					
			}
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		}
		return objInvite;
	}
	
	public static Object parseCandidateDetails(String candidate_detailsResponse)
	{

		logger.info("Inside parseCandidateDetails method.");
		CandidateDetailsforInvitation objCandidate = new CandidateDetailsforInvitation();
		try 
		{
			ObjectMapper mapper = new ObjectMapper();
			JsonNode root = mapper.readTree(candidate_detailsResponse);
			Iterator<String> fieldnames = root.getFieldNames();
			
			while (fieldnames.hasNext())
			{
				String fieldname = fieldnames.next();
				if("id".equals(fieldname))
				{
					objCandidate.setCandidateId(root.get(fieldname).getTextValue());
				}
				if("firstName".equals(fieldname))
				{
					objCandidate.setFirstName(root.get(fieldname).getTextValue());
				}
				if("lastName".equals(fieldname))
				{
					objCandidate.setLastName(root.get(fieldname).getTextValue());
				}
				if("email".equals(fieldname))
				{
					objCandidate.setEmail(root.get(fieldname).getTextValue());
				}
				if("gender".equals(fieldname))
				{
					objCandidate.setGender(root.get(fieldname).getTextValue());
				}
				if("phone".equals(fieldname))
				{
					objCandidate.setPhone(root.get(fieldname).getTextValue());
				}
				if("mobile".equals(fieldname))
				{
					objCandidate.setMobile(root.get(fieldname).getTextValue());
				}
				if("created".equals(fieldname))
				{
					objCandidate.setCreated(root.get(fieldname).getTextValue());
				}	
				if("modified".equals(fieldname))
				{
					objCandidate.setModified(root.get(fieldname).getTextValue());
				}
			}

		
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return objCandidate;
	}

	
	public static String generateAndSendEmail(String candidateEmail,String subject, String candidateName, String candidateLoginUrl, String expiryDate)
	{
		String status="";
		StringWriter content = null;
		ConfigDetails config = new ConfigDetails();
		Properties props = config.readPropertiesFileDetails("EmailConfig.properties");
		try
		{
			logger.info("Setting properties..");
			Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
	        Properties mailProps = new Properties();
	        mailProps.setProperty("mail.transport.protocol", props.getProperty("mail.transport.protocol"));
	        mailProps.setProperty("mail.host", props.getProperty("mail.host"));
	        mailProps.setProperty("mail.smtp.auth", props.getProperty("mail.smtp.auth"));
	        mailProps.setProperty("mail.smtp.port", props.getProperty("mail.smtp.port"));
	        mailProps.setProperty("mail.smtp.socketFactory.port", props.getProperty("mail.smtp.socketFactory.port"));
	        mailProps.setProperty("mail.smtp.socketFactory.class", props.getProperty("mail.smtp.socketFactory.class"));
	        mailProps.setProperty("mail.smtp.socketFactory.fallback", props.getProperty("mail.smtp.socketFactory.fallback"));
	        mailProps.setProperty("mail.smtp.quitwait", props.getProperty("mail.smtp.quitwait"));
	
	        logger.info("Properties set successfully..");
	        logger.info("Creating session..");
	        Session session = Session.getDefaultInstance(props,new javax.mail.Authenticator(){
	             protected PasswordAuthentication getPasswordAuthentication()
	             { return new PasswordAuthentication(props.getProperty("senderEmail"),props.getProperty("senderPassword"));     }
	        });          
	
	        logger.info("Session created..");
	        session.setDebug(true);
	        
	        try 
			{
	        	logger.info("Creating Template..");
	        	VelocityEngine ve = new VelocityEngine();
	        	ve.setProperty("resource.loader", "class");
	            ve.setProperty("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
	        	ve.init();
	        	VelocityContext context = new VelocityContext();
				context.put("Name" , candidateName);
				context.put("assessmentLink" , candidateLoginUrl);
//				context.put("expirydate" , expiryDate);
	        	Template template = ve.getTemplate("/Template/invitation_template.vm");
				content = new StringWriter();
				template.merge(context, content);
				  
				  
			} catch (ResourceNotFoundException e) {
				// TODO Auto-generated catch block
				logger.error(e.getMessage());
			} catch (ParseErrorException e) {
				// TODO Auto-generated catch block
				logger.error(e.getMessage());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				logger.error(e.getMessage());
			}
	        
	        logger.info("Creating Mimemessage..");
	        MimeMessage message = new MimeMessage(session);
	        message.setSender(new InternetAddress(props.getProperty("senderEmail")));
	        message.setSubject(subject);
	        message.setContent(content.toString(), "text/html");
			message.setRecipient(Message.RecipientType.TO, new InternetAddress(candidateEmail));
			message.setReplyTo(new InternetAddress[]{new InternetAddress(props.getProperty("replyTo"))});
			Transport.send(message);
			status = SFInvitationConstants.EMAIL_SENT_SUCCESS;
		} catch (AddressException e) {
			// TODO Auto-generated catch block
			status = SFInvitationConstants.EMAIL_SENT_FAILURE;
			logger.error(e.getMessage());
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			status = SFInvitationConstants.EMAIL_SENT_FAILURE;
			logger.error(e.getMessage());
		}
		catch (Exception e)
		{
			// TODO: handle exception
			status = SFInvitationConstants.EMAIL_SENT_FAILURE;
			logger.error(e.getMessage());
		}
		
		return status;
	}
	
}
