package main.java.com.revelian.candidate.model;

public class Result
{
	private String assessment;
	private String type;
    private String reportUrl;
    private String percentile;
    private String classification;
    private String validity;
    private String invitations;
    private String cognifyPackageResults;
    
    public String getAssessment() {
		return assessment;
	}
	public void setAssessment(String assessment) {
		this.assessment = assessment;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getReportUrl() {
		return reportUrl;
	}
	public void setReportUrl(String reportUrl) {
		this.reportUrl = reportUrl;
	}
	public String getPercentile() {
		return percentile;
	}
	public void setPercentile(String percentile) {
		this.percentile = percentile;
	}
	public String getClassification() {
		return classification;
	}
	public void setClassification(String classification) {
		this.classification = classification;
	}
	public String getValidity() {
		return validity;
	}
	public void setValidity(String validity) {
		this.validity = validity;
	}
	public String getInvitations() {
		return invitations;
	}
	public void setInvitations(String invitations) {
		this.invitations = invitations;
	}
	public String getCognifyPackageResults() {
		return cognifyPackageResults;
	}
	public void setCognifyPackageResults(String cognifyPackageResults) {
		this.cognifyPackageResults = cognifyPackageResults;
	}
	

}
